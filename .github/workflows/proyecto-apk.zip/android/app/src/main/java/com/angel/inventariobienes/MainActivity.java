package com.angel.inventariobienes;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Inventario de Bienes: la interfaz es una app web local (assets/www) servida
 * desde un origen https virtual. Los datos viven en IndexedDB dentro del
 * almacenamiento privado de la app. No hay permiso de internet.
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/index.html";
    private static final int REQ_FILE = 10;
    private static final int REQ_CAM = 11;
    private static final int REQ_STORAGE = 12;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingCamera;

    // escritura de archivos en Descargas
    private final Object fileLock = new Object();
    private OutputStream out;
    private Uri outUri;
    private String outName;
    private Uri lastUri;
    private String lastMime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#1F4D43"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#F3F4F1"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        WebView.setWebContentsDebuggingEnabled(false);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return asset(u.getPath());
                // Cualquier otro origen se bloquea: la app funciona sin red.
                return new WebResourceResponse("text/plain", "utf-8", 403, "Bloqueado",
                        new HashMap<>(), new ByteArrayInputStream(new byte[0]));
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if (scheme.equals("tel") || scheme.equals("mailto")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean video = Arrays.asList(request.getResources())
                            .contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE);
                    if (!video) { request.deny(); return; }
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        pendingCamera = request;
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAM);
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                boolean images = false;
                for (String t : params.getAcceptTypes()) if (t != null && t.contains("image")) images = true;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(images ? "image/*" : "*/*");
                if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(i, images ? "Seleccionar fotos" : "Seleccionar archivo"), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(START);
    }

    /** Sirve los archivos de assets/www para el origen virtual. */
    private WebResourceResponse asset(String path) {
        if (path == null || path.equals("/") || path.isEmpty()) path = "/index.html";
        try {
            InputStream in = getAssets().open("www" + path);
            WebResourceResponse r = new WebResourceResponse(mime(path), "utf-8", in);
            Map<String, String> h = new HashMap<>();
            h.put("Cache-Control", "no-cache");
            r.setResponseHeaders(h);
            return r;
        } catch (Exception e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                    new HashMap<>(), new ByteArrayInputStream(new byte[0]));
        }
    }

    private static String mime(String p) {
        p = p.toLowerCase();
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".js")) return "application/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".webp")) return "image/webp";
        return "application/octet-stream";
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                result = new Uri[n];
                for (int k = 0; k < n; k++) result[k] = data.getClipData().getItemAt(k).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_CAM && pendingCamera != null) {
            if (ok) pendingCamera.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            else pendingCamera.deny();
            pendingCamera = null;
        }
        if (requestCode == REQ_STORAGE) {
            Toast.makeText(this, ok ? "Permiso concedido. Repita la operación." : "Sin permiso no se pueden guardar archivos en Descargas.", Toast.LENGTH_LONG).show();
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.__back ? window.__back() : false)", v -> {
            if (!"true".equals(v)) super.onBackPressed();
        });
    }

    @Override protected void onPause() { web.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override protected void onSaveInstanceState(Bundle outState) { super.onSaveInstanceState(outState); web.saveState(outState); }

    /** Puente JavaScript ↔ Android (se ejecuta en un hilo de fondo). */
    private class Bridge {
        @JavascriptInterface public boolean isNative() { return true; }
        @JavascriptInterface public String version() { return BuildConfigVersion.name(MainActivity.this); }

        /** Abre un archivo nuevo en Descargas/Inventario. */
        @JavascriptInterface
        public boolean beginFile(String name, String mimeType) {
            synchronized (fileLock) {
                closeQuietly();
                try {
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                        v.put(MediaStore.MediaColumns.MIME_TYPE, mimeType);
                        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Inventario");
                        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                        outUri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                        if (outUri == null) return false;
                        out = getContentResolver().openOutputStream(outUri);
                    } else {
                        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE));
                            return false;
                        }
                        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Inventario");
                        if (!dir.exists() && !dir.mkdirs()) return false;
                        File f = new File(dir, name);
                        out = new FileOutputStream(f);
                        outUri = Uri.fromFile(f);
                    }
                    outName = name;
                    lastMime = mimeType;
                    return out != null;
                } catch (Exception e) {
                    closeQuietly();
                    return false;
                }
            }
        }

        @JavascriptInterface
        public boolean appendText(String chunk) {
            synchronized (fileLock) {
                if (out == null) return false;
                try { out.write(chunk.getBytes(StandardCharsets.UTF_8)); return true; }
                catch (Exception e) { return false; }
            }
        }

        @JavascriptInterface
        public String endFile() {
            synchronized (fileLock) {
                if (out == null) return "";
                try {
                    out.flush();
                    out.close();
                    out = null;
                    if (Build.VERSION.SDK_INT >= 29 && outUri != null) {
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                        getContentResolver().update(outUri, v, null, null);
                    }
                    lastUri = outUri;
                    return "Descargas/Inventario/" + outName;
                } catch (Exception e) {
                    closeQuietly();
                    return "";
                }
            }
        }

        /** Comparte el último archivo guardado (por ejemplo, para copiar el respaldo a otro lugar). */
        @JavascriptInterface
        public boolean shareLast() {
            if (lastUri == null || Build.VERSION.SDK_INT < 29) return false;
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType(lastMime == null ? "*/*" : lastMime);
                i.putExtra(Intent.EXTRA_STREAM, lastUri);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivity(Intent.createChooser(i, "Enviar archivo")); } catch (Exception ignored) { }
            });
            return true;
        }

        /** Imprime o guarda en PDF la vista actual (usa los estilos @media print). */
        @JavascriptInterface
        public void print(final String title) {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                if (pm == null) return;
                String t = (title == null || title.isEmpty()) ? "Inventario" : title;
                PrintDocumentAdapter adapter = web.createPrintDocumentAdapter(t);
                PrintAttributes attrs = new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .build();
                pm.print(t, adapter, attrs);
            });
        }
    }

    private void closeQuietly() {
        try { if (out != null) out.close(); } catch (Exception ignored) { }
        out = null;
    }

    /** Lee la versión instalada sin depender de BuildConfig. */
    static final class BuildConfigVersion {
        static String name(Activity a) {
            try { return a.getPackageManager().getPackageInfo(a.getPackageName(), 0).versionName; }
            catch (Exception e) { return ""; }
        }
    }
}
