/* Inventario de Bienes · app local (sin servidor, sin internet)
   Base de datos: IndexedDB del dispositivo. Fotos guardadas como JPEG dentro de la base.
   Movimientos encadenados con SHA-256 (registro a prueba de alteraciones). */
'use strict';
const APP_VERSION = '1.0.0';

/* ───────────── utilidades ───────────── */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
const nowISO = () => new Date().toISOString();
const num = v => { const n = Number(String(v ?? '').replace(',', '.')); return isFinite(n) ? n : 0; };
const norm = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
const sleep = ms => new Promise(r => setTimeout(r, ms));
function toLocalInput(d = new Date()) { d = new Date(d); return new Date(d - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16); }
function todayStr() { return toLocalInput().slice(0, 10); }
function fmtDT(iso) { if (!iso) return '—'; const d = new Date(iso); return isNaN(d) ? iso : d.toLocaleString('es-CO', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }); }
function fmtD(s) { if (!s) return '—'; const d = s.length === 10 ? new Date(s + 'T12:00:00') : new Date(s); return isNaN(d) ? s : d.toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' }); }
function fmtMoney(v) { try { return new Intl.NumberFormat('es-CO', { style: 'currency', currency: CFG.moneda || 'COP', maximumFractionDigits: 0 }).format(v || 0); } catch { return '$ ' + Math.round(v || 0).toLocaleString('es-CO'); } }
function daysSince(iso) { return iso ? (Date.now() - new Date(iso)) / 864e5 : Infinity; }
function toast(msg, ms = 2600) { const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), ms); }
function qs() { const h = location.hash, i = h.indexOf('?'); return new URLSearchParams(i >= 0 ? h.slice(i + 1) : ''); }
function go(h, replace) { if (replace) location.replace(h); else location.hash = h; }
const NATIVE = !!(window.AndroidBridge && AndroidBridge.isNative && AndroidBridge.isNative());

/* ───────────── SHA-256 ───────────── */
async function sha256(text) {
  const data = new TextEncoder().encode(text);
  if (window.crypto && crypto.subtle) {
    const h = await crypto.subtle.digest('SHA-256', data);
    return [...new Uint8Array(h)].map(b => b.toString(16).padStart(2, '0')).join('');
  }
  return sha256js(data);
}
function sha256js(bytes) { // respaldo para contextos sin crypto.subtle
  const K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  const H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  const l = bytes.length, nb = ((l + 9 + 63) >> 6) << 6, m = new Uint8Array(nb);
  m.set(bytes); m[l] = 0x80; const dv = new DataView(m.buffer);
  dv.setUint32(nb - 4, (l * 8) >>> 0); dv.setUint32(nb - 8, Math.floor(l / 0x20000000));
  const w = new Uint32Array(64), r = (x, n) => (x >>> n) | (x << (32 - n));
  for (let o = 0; o < nb; o += 64) {
    for (let i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
    for (let i = 16; i < 64; i++) { const s0 = r(w[i-15],7) ^ r(w[i-15],18) ^ (w[i-15] >>> 3), s1 = r(w[i-2],17) ^ r(w[i-2],19) ^ (w[i-2] >>> 10); w[i] = (w[i-16] + s0 + w[i-7] + s1) >>> 0; }
    let [a,b,c,d,e,f,g,h] = H;
    for (let i = 0; i < 64; i++) { const t1 = (h + (r(e,6) ^ r(e,11) ^ r(e,25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) >>> 0, t2 = ((r(a,2) ^ r(a,13) ^ r(a,22)) + ((a & b) ^ (a & c) ^ (b & c))) >>> 0; h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0; }
    H[0]=(H[0]+a)>>>0;H[1]=(H[1]+b)>>>0;H[2]=(H[2]+c)>>>0;H[3]=(H[3]+d)>>>0;H[4]=(H[4]+e)>>>0;H[5]=(H[5]+f)>>>0;H[6]=(H[6]+g)>>>0;H[7]=(H[7]+h)>>>0;
  }
  return H.map(x => x.toString(16).padStart(8, '0')).join('');
}

/* ───────────── base de datos (IndexedDB) ───────────── */
const DB = {
  db: null,
  open() {
    return new Promise((res, rej) => {
      const r = indexedDB.open('inventario-bienes', 1);
      r.onupgradeneeded = () => {
        const d = r.result;
        d.createObjectStore('items', { keyPath: 'id' });
        const m = d.createObjectStore('movs', { keyPath: 'id' });
        m.createIndex('item', 'itemId'); m.createIndex('n', 'n', { unique: true });
        d.createObjectStore('fotos', { keyPath: 'id' });
        d.createObjectStore('personas', { keyPath: 'id' });
        d.createObjectStore('config', { keyPath: 'k' });
      };
      r.onsuccess = () => { DB.db = r.result; res(); };
      r.onerror = () => rej(r.error);
    });
  },
  req(store, mode, fn) {
    return new Promise((res, rej) => {
      const t = DB.db.transaction(store, mode), s = t.objectStore(store); let out;
      const q = fn(s); if (q) q.onsuccess = () => { out = q.result; };
      t.oncomplete = () => res(out); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error);
    });
  },
  get: (st, k) => DB.req(st, 'readonly', s => s.get(k)),
  all: (st) => DB.req(st, 'readonly', s => s.getAll()),
  put: (st, v) => DB.req(st, 'readwrite', s => s.put(v)),
  del: (st, k) => DB.req(st, 'readwrite', s => s.delete(k)),
  byIndex: (st, ix, v) => DB.req(st, 'readonly', s => s.index(ix).getAll(v)),
  count: (st) => DB.req(st, 'readonly', s => s.count()),
  /** escribe varias cosas en una sola transacción atómica: ops = [[store, value], ...] */
  write(ops) {
    const stores = [...new Set(ops.map(o => o[0]))];
    return new Promise((res, rej) => {
      const t = DB.db.transaction(stores, 'readwrite');
      ops.forEach(([st, v, del]) => del ? t.objectStore(st).delete(v) : t.objectStore(st).put(v));
      t.oncomplete = () => res(); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error || new Error('Transacción abortada'));
    });
  },
  clearAll() { return new Promise((res, rej) => { const names = ['items', 'movs', 'fotos', 'personas', 'config']; const t = DB.db.transaction(names, 'readwrite'); names.forEach(n => t.objectStore(n).clear()); t.oncomplete = res; t.onerror = () => rej(t.error); }); }
};

/* ───────────── configuración ───────────── */
const DEF_CFG = {
  propiedad: { nombre: '', direccion: '', ciudad: '', responsable: '', telefono: '', notas: '' },
  prefijo: 'BN-', siguiente: 1, moneda: 'COP', diasValidacion: 30,
  categorias: ['Mobiliario', 'Electrodomésticos', 'Electrónica y tecnología', 'Herramientas y equipos', 'Vehículos y maquinaria', 'Menaje y cocina', 'Lencería y textiles', 'Arte y decoración', 'Jardín y exteriores', 'Documentos y títulos', 'Inmueble', 'Otros'],
  ubicaciones: ['Sala', 'Comedor', 'Cocina', 'Habitación principal', 'Habitación 2', 'Habitación 3', 'Baños', 'Estudio', 'Garaje', 'Bodega', 'Patio / jardín', 'Exterior'],
  pinHash: null, pinSalt: null, ultimoRespaldo: null, setupHecho: false
};
let CFG = structuredClone(DEF_CFG);
async function loadCfg() { const r = await DB.get('config', 'cfg'); CFG = Object.assign(structuredClone(DEF_CFG), r ? r.v : {}); }
async function saveCfg() { await DB.put('config', { k: 'cfg', v: CFG }); }

/* ───────────── catálogos de dominio ───────────── */
const TIPOS = {
  alta: { l: 'Ingreso inicial', i: '★', c: 'b-info' },
  entrada: { l: 'Entrada / retorno', i: '↘', c: 'b-ok' },
  salida: { l: 'Salida', i: '↗', c: 'b-warn' },
  traslado: { l: 'Traslado interno', i: '⇄', c: 'b-info' },
  validacion: { l: 'Validación', i: '✓', c: 'b-info' },
  novedad: { l: 'Novedad', i: '!', c: 'b-warn' },
  ajuste: { l: 'Ajuste', i: '±', c: 'b-off' },
  baja: { l: 'Baja', i: '✕', c: 'b-bad' },
  edicion: { l: 'Edición de datos', i: '✎', c: 'b-off' },
  anulacion: { l: 'Anulación', i: '⊘', c: 'b-bad' }
};
const SIT = { en_sitio: ['En la propiedad', 'b-ok'], parcial: ['Parcialmente fuera', 'b-warn'], fuera: ['Fuera de la propiedad', 'b-warn'], baja: ['Dado de baja', 'b-off'] };
const ESTADOS = ['Nuevo', 'Bueno', 'Regular', 'Malo', 'Inservible'];
const RESULTADOS = { conforme: ['Conforme', 'b-ok'], con_novedad: ['Con novedad', 'b-warn'], no_encontrado: ['No encontrado', 'b-bad'] };
const TIPOS_NOVEDAD = ['Daño', 'Reparación', 'Mantenimiento', 'Faltante parcial', 'Mejora', 'Avalúo / revaluación', 'Otro'];
const MOTIVOS_BAJA = ['Venta', 'Donación', 'Daño irreparable', 'Pérdida', 'Hurto', 'Obsolescencia', 'Otro'];

const valorItem = it => it.baja ? 0 : num(it.valorUnit) * num(it.cantidad);
const cantFuera = it => (it.fuera || []).reduce((a, f) => a + num(f.cantidad), 0);
const disponible = it => it.baja ? 0 : num(it.cantidad) - cantFuera(it);
function sitOf(it) { if (it.baja) return 'baja'; const f = cantFuera(it); if (f <= 0) return 'en_sitio'; return f >= num(it.cantidad) ? 'fuera' : 'parcial'; }
function vencidas(it) { const t = todayStr(); return (it.fuera || []).filter(f => f.retornoEsperado && f.retornoEsperado < t); }
function ultimaRevision(it) { return it.ultimaValidacion || it.creado; }
function pendienteValidar(it) { return !it.baja && daysSince(ultimaRevision(it)) > num(CFG.diasValidacion || 30); }
function badgeSit(it) {
  let h = `<span class="badge ${SIT[sitOf(it)][1]}">${SIT[sitOf(it)][0]}</span>`;
  if (it.alerta === 'no_encontrado') h += ` <span class="badge b-bad">No encontrado</span>`;
  else if (vencidas(it).length) h += ` <span class="badge b-bad">Retorno vencido</span>`;
  return h;
}
const tipoBadge = t => `<span class="badge ${TIPOS[t]?.c || 'b-off'}">${TIPOS[t]?.i || ''} ${TIPOS[t]?.l || t}</span>`;

/* ───────────── motor de movimientos ───────────── */
let _cola = Promise.resolve();
function enCola(fn) { const p = _cola.then(fn, fn); _cola = p.catch(() => {}); return p; }
function canon(m) { return JSON.stringify(Object.keys(m).filter(k => k !== 'hash' && k !== 'anuladoPor').sort().map(k => [k, m[k]])); }
function limpiar(o) { for (const k of Object.keys(o)) if (o[k] === undefined || o[k] === null || o[k] === '' || (Array.isArray(o[k]) && !o[k].length && k !== 'fotos')) delete o[k]; return o; }

/** Aplica las reglas del movimiento sobre una copia del bien. Lanza Error si no es válido. */
function aplicar(it, m) {
  const q = Math.max(1, Math.floor(num(m.cantidad) || 1));
  switch (m.tipo) {
    case 'alta': m.cantidad = num(it.cantidad); break;
    case 'salida': {
      if (it.baja) throw new Error('El bien está dado de baja.');
      if (it.tipoBien === 'inmueble') throw new Error('Un inmueble no registra salidas. Use "Novedad" o "Validación".');
      if (q > disponible(it)) throw new Error(`Solo hay ${disponible(it)} unidad(es) disponibles en la propiedad.`);
      m.cantidad = q; m.origen = it.ubicacion;
      it.fuera = [...(it.fuera || []), { n: m.n, persona: m.recibe, cantidad: q, fecha: m.fecha, retornoEsperado: m.retornoEsperado || null, destino: m.destino || null }];
      break;
    }
    case 'entrada': {
      const f = (it.fuera || []).find(x => x.n === num(m.refN));
      if (!f) throw new Error('Seleccione la salida que se está devolviendo.');
      if (q > num(f.cantidad)) throw new Error(`Esa salida tiene ${f.cantidad} unidad(es) pendientes.`);
      m.cantidad = q;
      it.fuera = it.fuera.map(x => x.n === f.n ? { ...x, cantidad: num(x.cantidad) - q } : x).filter(x => num(x.cantidad) > 0);
      if (m.estadoFisico) it.estadoFisico = m.estadoFisico;
      if (m.destino) { m.origen = it.ubicacion; it.ubicacion = m.destino; }
      break;
    }
    case 'traslado':
      if (it.baja) throw new Error('El bien está dado de baja.');
      if (!m.destino) throw new Error('Indique la nueva ubicación.');
      if (m.destino === it.ubicacion) throw new Error('La nueva ubicación es igual a la actual.');
      m.origen = it.ubicacion; it.ubicacion = m.destino; break;
    case 'validacion':
      if (!RESULTADOS[m.resultado]) throw new Error('Indique el resultado de la validación.');
      it.ultimaValidacion = m.fecha; it.ultimoResultado = m.resultado;
      if (m.estadoFisico) it.estadoFisico = m.estadoFisico;
      it.alerta = m.resultado === 'no_encontrado' ? 'no_encontrado' : null;
      if (m.destino && m.destino !== it.ubicacion) { m.origen = it.ubicacion; it.ubicacion = m.destino; }
      break;
    case 'novedad':
      if (m.estadoFisico) it.estadoFisico = m.estadoFisico;
      if (m.valor !== undefined && m.valor !== '' && m.valor !== null) { m.valorAnterior = num(it.valorUnit); it.valorUnit = num(m.valor); }
      break;
    case 'ajuste': {
      if (m.nuevaCantidad !== undefined && m.nuevaCantidad !== '') {
        const nc = Math.floor(num(m.nuevaCantidad));
        if (nc < 1) throw new Error('La cantidad mínima es 1. Para retirar el bien use "Baja".');
        if (nc < cantFuera(it)) throw new Error(`Hay ${cantFuera(it)} unidad(es) fuera; la cantidad no puede ser menor.`);
        m.cantidadAnterior = num(it.cantidad); it.cantidad = nc;
      }
      if (m.valor !== undefined && m.valor !== '') { m.valorAnterior = num(it.valorUnit); it.valorUnit = num(m.valor); }
      if (m.cantidadAnterior === undefined && m.valorAnterior === undefined) throw new Error('Indique la nueva cantidad o el nuevo valor.');
      break;
    }
    case 'baja':
      if (it.baja) throw new Error('El bien ya está dado de baja.');
      if (cantFuera(it) > 0) m.detalle = (m.detalle ? m.detalle + ' · ' : '') + `Se cerraron ${cantFuera(it)} unidad(es) que estaban fuera.`;
      it.baja = true; it.fechaBaja = m.fecha; it.motivoBaja = m.motivo; it.fuera = []; break;
    case 'edicion': case 'anulacion': break;
    default: throw new Error('Tipo de movimiento desconocido.');
  }
  it.situacion = sitOf(it); it.actualizado = nowISO(); it.ultimoMov = m.n;
  return it;
}

/**
 * Registra un movimiento de forma atómica: movimiento + bien actualizado + fotos nuevas + eslabón de la cadena.
 * fotosNuevas: [{id, blob, thumb, w, h, fecha}]; extraOps: operaciones adicionales en la misma transacción.
 */
function registrarMov(m, itemNuevo, fotosNuevas = [], extraOps = []) {
  return enCola(async () => {
    const cad = (await DB.get('config', 'cadena'))?.v || { n: 0, hash: '0'.repeat(64) };
    m.id = m.id || uid(); m.n = cad.n + 1; m.registrado = nowISO(); m.hashPrev = cad.hash;
    m.fecha = m.fecha || m.registrado;
    let it = itemNuevo ? structuredClone(itemNuevo) : (m.itemId ? await DB.get('items', m.itemId) : null);
    if (m.itemId && !it) throw new Error('Bien no encontrado.');
    if (it) { aplicar(it, m); m.snap = { codigo: it.codigo, nombre: it.nombre }; }
    m.fotos = [...(m.fotos || [])];
    for (const f of fotosNuevas) if (f.ref?.tipo !== 'firma' && !m.fotos.includes(f.id)) m.fotos.push(f.id);
    limpiar(m);
    m.hash = await sha256(canon(m));
    const ops = [['movs', m], ['config', { k: 'cadena', v: { n: m.n, hash: m.hash } }]];
    if (it) ops.push(['items', it]);
    for (const f of fotosNuevas) ops.push(['fotos', { id: f.id, blob: f.blob, thumb: f.thumb, w: f.w, h: f.h, fecha: f.fecha, ref: f.ref || { tipo: 'mov', id: m.id, itemId: m.itemId } }]);
    ops.push(...extraOps);
    await DB.write(ops);
    return { mov: m, item: it };
  });
}

async function verificarCadena() {
  const movs = (await DB.all('movs')).sort((a, b) => a.n - b.n);
  let prev = '0'.repeat(64), errores = [];
  for (let i = 0; i < movs.length; i++) {
    const m = movs[i];
    if (m.n !== i + 1) errores.push(`Falta el movimiento N.º ${i + 1}`);
    if (m.hashPrev !== prev) errores.push(`N.º ${m.n}: el enlace con el anterior no coincide`);
    if (await sha256(canon(m)) !== m.hash) errores.push(`N.º ${m.n}: el contenido fue modificado`);
    prev = m.hash;
    if (errores.length > 20) break;
  }
  const cad = (await DB.get('config', 'cadena'))?.v;
  if (movs.length && cad && cad.hash !== prev) errores.push('El último eslabón registrado no coincide');
  return { total: movs.length, errores };
}

/* ───────────── personas ───────────── */
let PERSONAS = [];
async function loadPersonas() { PERSONAS = (await DB.all('personas')).sort((a, b) => a.nombre.localeCompare(b.nombre, 'es')); }
const findPersona = n => PERSONAS.find(p => norm(p.nombre) === norm(n));
/** Devuelve operación para crear/actualizar la persona si no existe (para incluir en la transacción). */
function opsPersona(nombre, doc, tel, rol) {
  nombre = String(nombre || '').trim(); if (!nombre) return [];
  const p = findPersona(nombre);
  if (!p) { const np = { id: uid(), nombre, documento: doc || '', telefono: tel || '', rol: rol || 'Otro', notas: '', creado: nowISO() }; PERSONAS.push(np); return [['personas', np]]; }
  let ch = false; if (doc && !p.documento) { p.documento = doc; ch = true; } if (tel && !p.telefono) { p.telefono = tel; ch = true; }
  return ch ? [['personas', p]] : [];
}
function dlPersonas() { return `<datalist id="dlp">${PERSONAS.map(p => `<option value="${esc(p.nombre)}">${esc(p.rol || '')}${p.documento ? ' · ' + esc(p.documento) : ''}</option>`).join('')}</datalist>`; }

/* ───────────── fotos ───────────── */
const URLS = new Map();
async function fotoURL(id, full) {
  const key = id + (full ? ':f' : ':t'); if (URLS.has(key)) return URLS.get(key);
  const f = await DB.get('fotos', id); if (!f) return '';
  const u = URL.createObjectURL(full ? f.blob : (f.thumb || f.blob)); URLS.set(key, u); return u;
}
const PEND = new Map(); // fotos aún no guardadas (en formularios)
function hydrate(root = document) {
  $$('img[data-foto]:not([src])', root).forEach(async img => {
    const id = img.dataset.foto;
    if (PEND.has(id)) { img.src = PEND.get(id).url; return; }
    const u = await fotoURL(id, img.dataset.full === '1'); if (u) img.src = u;
  });
}
async function loadImageSource(file) {
  try { return await createImageBitmap(file, { imageOrientation: 'from-image' }); }
  catch { return await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = URL.createObjectURL(file); }); }
}
function canvasToBlob(c, q) { return new Promise(r => c.toBlob(r, 'image/jpeg', q)); }
/** Reduce, sella con fecha/hora y etiqueta, y genera miniatura. */
async function procesarImagen(src, sw, sh, etiqueta) {
  const MAX = 1600, s = Math.min(1, MAX / Math.max(sw, sh)), w = Math.round(sw * s), h = Math.round(sh * s);
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const x = c.getContext('2d'); x.drawImage(src, 0, 0, w, h);
  const fecha = nowISO();
  const txt = `${etiqueta ? etiqueta + ' · ' : ''}${new Date(fecha).toLocaleString('es-CO')}`;
  const fs = Math.max(14, Math.round(w / 42));
  x.fillStyle = 'rgba(0,0,0,.55)'; x.fillRect(0, h - fs * 1.9, w, fs * 1.9);
  x.fillStyle = '#fff'; x.font = `600 ${fs}px system-ui,sans-serif`; x.textBaseline = 'middle'; x.fillText(txt, fs * .6, h - fs * .95, w - fs * 1.2);
  const blob = await canvasToBlob(c, .82);
  const ts = Math.min(1, 320 / Math.max(w, h)), t = document.createElement('canvas'); t.width = Math.round(w * ts); t.height = Math.round(h * ts);
  t.getContext('2d').drawImage(c, 0, 0, t.width, t.height);
  const thumb = await canvasToBlob(t, .72);
  const f = { id: uid(), blob, thumb, w, h, fecha, url: URL.createObjectURL(thumb) };
  PEND.set(f.id, f); return f;
}
async function fotosDesdeArchivos(files, etiqueta) {
  const out = [];
  for (const file of files) {
    try { const src = await loadImageSource(file); out.push(await procesarImagen(src, src.width || src.naturalWidth, src.height || src.naturalHeight, etiqueta)); }
    catch (e) { toast('No se pudo leer una imagen'); }
  }
  return out;
}
function pickFiles(input) {
  return new Promise(res => {
    const el = $(input); el.value = '';
    const done = () => { el.removeEventListener('change', done); res([...el.files]); };
    el.addEventListener('change', done); el.click();
  });
}
async function galeria(etiqueta) { const files = await pickFiles('#filePick'); return fotosDesdeArchivos(files, etiqueta); }

/* cámara dentro de la app */
let MODAL = null; // función para cerrar el modal abierto (botón atrás)
function abrirCamara(etiqueta) {
  return new Promise(async resolve => {
    const fotos = [];
    let stream;
    try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1440 } }, audio: false }); }
    catch (e) {
      toast('Cámara no disponible; se abrirá el selector de imágenes.');
      const files = await pickFiles('#fileCam'); resolve(await fotosDesdeArchivos(files, etiqueta)); return;
    }
    const m = document.createElement('div'); m.className = 'modal full';
    m.innerHTML = `<div class="cam"><video playsinline autoplay muted></video><div class="flash"></div>
      <div class="bar"><span class="cnt">0 fotos</span><button class="shot" aria-label="Tomar foto"></button><button class="ok">Listo</button></div></div>`;
    document.body.appendChild(m);
    const v = $('video', m); v.srcObject = stream;
    const cerrar = () => { stream.getTracks().forEach(t => t.stop()); m.remove(); MODAL = null; resolve(fotos); };
    MODAL = cerrar;
    $('.ok', m).onclick = cerrar;
    $('.shot', m).onclick = async () => {
      if (!v.videoWidth) return;
      const fl = $('.flash', m); fl.style.opacity = .8; setTimeout(() => fl.style.opacity = 0, 120);
      fotos.push(await procesarImagen(v, v.videoWidth, v.videoHeight, etiqueta));
      $('.cnt', m).textContent = fotos.length + (fotos.length === 1 ? ' foto' : ' fotos');
    };
  });
}
/* visor de fotos */
function verFoto(ids, i) {
  const m = document.createElement('div'); m.className = 'viewer';
  m.innerHTML = `<img alt=""><div class="bar"><button class="sec p">‹</button><span class="c"></span><button class="sec n">›</button><button class="x">Cerrar</button></div>`;
  document.body.appendChild(m);
  const show = async () => { $('.c', m).textContent = `${i + 1} / ${ids.length}`; const img = $('img', m); img.removeAttribute('src'); img.src = PEND.has(ids[i]) ? URL.createObjectURL(PEND.get(ids[i]).blob) : await fotoURL(ids[i], true); };
  $('.p', m).onclick = () => { i = (i - 1 + ids.length) % ids.length; show(); };
  $('.n', m).onclick = () => { i = (i + 1) % ids.length; show(); };
  const cerrar = () => { m.remove(); MODAL = null; }; $('.x', m).onclick = cerrar; MODAL = cerrar;
  if (ids.length < 2) { $('.p', m).classList.add('hide'); $('.n', m).classList.add('hide'); }
  show();
}
document.addEventListener('click', e => {
  const img = e.target.closest('img[data-foto]'); if (!img || e.target.closest('.x') || img.closest('a')) return;
  const g = img.closest('[data-gal]'); const ids = g ? $$('img[data-foto]', g).map(x => x.dataset.foto) : [img.dataset.foto];
  verFoto(ids, Math.max(0, ids.indexOf(img.dataset.foto)));
});
function tiraFotos(ids, opts = {}) {
  return `<div class="photos ${opts.mini ? 'mini' : ''}" data-gal>${ids.map(id => `<div class="ph"><img data-foto="${id}" alt="foto">${opts.quitar ? `<button class="x" data-quitar="${id}" type="button">✕</button>` : ''}</div>`).join('')}
  ${opts.agregar ? `<button type="button" class="add" data-cam><b>📷</b>Cámara</button><button type="button" class="add" data-gal-add><b>🖼</b>Galería</button>` : ''}</div>`;
}

/* firma */
function capturarFirma(titulo) {
  return new Promise(resolve => {
    const m = document.createElement('div'); m.className = 'modal';
    m.innerHTML = `<div class="sheet"><h2>${esc(titulo)}</h2><p class="muted small">Firme con el dedo dentro del recuadro.</p>
      <canvas class="sig"></canvas><div class="row" style="margin-top:10px"><button class="sec grow" data-a="lim">Limpiar</button><button class="sec grow" data-a="can">Cancelar</button><button class="grow" data-a="ok">Guardar firma</button></div></div>`;
    document.body.appendChild(m);
    const c = $('canvas', m), r = c.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
    c.width = r.width * dpr; c.height = r.height * dpr;
    const x = c.getContext('2d'); x.scale(dpr, dpr); x.lineWidth = 2.4; x.lineCap = 'round'; x.lineJoin = 'round'; x.strokeStyle = '#111';
    let dib = false, vacio = true;
    const p = e => { const b = c.getBoundingClientRect(); return [e.clientX - b.left, e.clientY - b.top]; };
    c.onpointerdown = e => { dib = true; vacio = false; c.setPointerCapture(e.pointerId); x.beginPath(); x.moveTo(...p(e)); };
    c.onpointermove = e => { if (!dib) return; x.lineTo(...p(e)); x.stroke(); };
    c.onpointerup = c.onpointercancel = () => { dib = false; };
    const cerrar = v => { m.remove(); MODAL = null; resolve(v); }; MODAL = () => cerrar(null);
    m.onclick = async e => {
      const a = e.target.dataset.a; if (!a) return;
      if (a === 'lim') { x.clearRect(0, 0, c.width, c.height); vacio = true; }
      if (a === 'can') cerrar(null);
      if (a === 'ok') {
        if (vacio) return toast('La firma está vacía');
        const o = document.createElement('canvas'); o.width = c.width; o.height = c.height; const ox = o.getContext('2d');
        ox.fillStyle = '#fff'; ox.fillRect(0, 0, o.width, o.height); ox.drawImage(c, 0, 0);
        const blob = await canvasToBlob(o, .9); const f = { id: uid(), blob, thumb: blob, w: o.width, h: o.height, fecha: nowISO(), url: URL.createObjectURL(blob) };
        PEND.set(f.id, f); cerrar(f);
      }
    };
  });
}

/* diálogo simple */
function dialogo(titulo, html, botones = [['Cancelar', 'sec', null], ['Aceptar', '', true]]) {
  return new Promise(resolve => {
    const m = document.createElement('div'); m.className = 'modal';
    m.innerHTML = `<div class="sheet"><h2>${esc(titulo)}</h2><div class="dlg-body" style="margin:10px 0 14px">${html}</div>
      <div class="row">${botones.map((b, i) => `<button class="grow ${b[1]}" data-i="${i}">${esc(b[0])}</button>`).join('')}</div></div>`;
    document.body.appendChild(m);
    const cerrar = v => { m.remove(); MODAL = null; resolve(v); }; MODAL = () => cerrar(null);
    m.addEventListener('click', e => { const i = e.target.dataset.i; if (i === undefined) { if (e.target === m) cerrar(null); return; } const v = botones[i][2]; cerrar(typeof v === 'function' ? v(m) : v); });
    const f = $('input,textarea,select', m); if (f) setTimeout(() => f.focus(), 50);
  });
}
const confirmar = (t, msg, ok = 'Aceptar', cls = '') => dialogo(t, `<p>${msg}</p>`, [['Cancelar', 'sec', null], [ok, cls, true]]);
const pedirTexto = (t, label, val = '', area) => dialogo(t, `<label class="f">${esc(label)}</label>${area ? `<textarea id="dlgv">${esc(val)}</textarea>` : `<input id="dlgv" value="${esc(val)}">`}`, [['Cancelar', 'sec', null], ['Aceptar', '', m => $('#dlgv', m).value.trim()]]);

/* ───────────── formularios ───────────── */
function fld(label, k, S, o = {}) {
  const v = S[k] ?? '', req = o.req ? ' <span class="req">*</span>' : '', cls = o.full ? 'full' : '';
  let ctl;
  if (o.opts) ctl = `<select data-k="${k}">${o.vacio !== false ? `<option value="">${o.vacio || '— Seleccione —'}</option>` : ''}${o.opts.map(x => { const [val, txt] = Array.isArray(x) ? x : [x, x]; return `<option value="${esc(val)}" ${String(val) === String(v) ? 'selected' : ''}>${esc(txt)}</option>`; }).join('')}</select>`;
  else if (o.type === 'textarea') ctl = `<textarea data-k="${k}" placeholder="${esc(o.ph || '')}">${esc(v)}</textarea>`;
  else ctl = `<input data-k="${k}" type="${o.type || 'text'}" value="${esc(v)}" placeholder="${esc(o.ph || '')}" ${o.list ? `list="${o.list}"` : ''} ${o.attrs || ''}>`;
  return `<div class="${cls}"><label class="f">${esc(label)}${req}</label>${ctl}${o.help !== undefined ? `<div class="small muted" style="margin-top:3px">${o.help}</div>` : ''}</div>`;
}
function bindForm(root, S, onChange) {
  const h = e => { const k = e.target.dataset.k; if (!k) return; S[k] = e.target.type === 'checkbox' ? e.target.checked : e.target.value; onChange && onChange(k, e); };
  root.addEventListener('input', h); root.addEventListener('change', h);
}
/** Gestiona la tira de fotos pendientes de un formulario */
function bindFotos(root, S, etiquetaFn, rerender) {
  root.addEventListener('click', async e => {
    if (e.target.closest('[data-cam]')) { const n = await abrirCamara(etiquetaFn()); S.fotos.push(...n); rerender(); }
    else if (e.target.closest('[data-gal-add]')) { const n = await galeria(etiquetaFn()); S.fotos.push(...n); rerender(); }
    else if (e.target.closest('[data-quitar]')) { const id = e.target.closest('[data-quitar]').dataset.quitar; S.fotos = S.fotos.filter(f => f.id !== id); rerender(); }
  });
}

/* ───────────── marco de pantallas ───────────── */
let main = $('#main');
let RT = 0;
function frame(title, sub = '', back = false, tab = '') {
  $('#hTitle').textContent = title; $('#hSub').textContent = sub || CFG.propiedad.nombre || '';
  $('#btnBack').classList.toggle('hide', !back);
  $$('#nav a').forEach(a => a.classList.toggle('on', a.dataset.v === tab));
  window.scrollTo(0, 0);
}
$('#btnBack').onclick = () => history.length > 1 ? history.back() : go('#/inicio');
$('#btnSearch').onclick = () => { go('#/bienes'); setTimeout(() => $('#q')?.focus(), 150); };
function itemRow(it, href, extra = '') {
  return `<a class="item" href="${href || '#/bien/' + it.id}"><div class="thumb">${it.fotos?.length ? `<img data-foto="${it.fotos[0]}" alt="">` : (it.tipoBien === 'inmueble' ? '⌂' : '▦')}</div>
  <div class="grow"><div class="nm">${esc(it.nombre)}</div><div class="sub">${esc(it.codigo)} · ${esc(it.ubicacion || '')}${num(it.cantidad) > 1 ? ' · ' + it.cantidad + ' ' + esc(it.unidad || 'und') : ''}</div><div style="margin-top:3px">${badgeSit(it)}${extra}</div></div>
  <div class="val">${fmtMoney(valorItem(it))}</div></a>`;
}
function movRow(m, conItem = true) {
  const persona = m.tipo === 'salida' ? `Se lo lleva: ${m.recibe}` : m.tipo === 'entrada' ? `Lo entrega: ${m.entrega}` : m.entrega || m.recibe || m.autoriza || '';
  return `<a class="item" href="#/movimiento/${m.id}"><div class="thumb">${m.fotos?.length ? `<img data-foto="${m.fotos[0]}" alt="">` : TIPOS[m.tipo]?.i}</div>
  <div class="grow"><div class="row between"><span>${tipoBadge(m.tipo)}${m.anuladoPor ? ' <span class="badge b-bad">Anulado</span>' : ''}</span><span class="small muted">N.º ${m.n}</span></div>
  ${conItem && m.snap ? `<div class="nm" style="margin-top:3px">${esc(m.snap.nombre)} <span class="muted small">${esc(m.snap.codigo)}</span></div>` : ''}
  <div class="sub">${fmtDT(m.fecha)}${persona ? ' · ' + esc(persona) : ''}${m.resultado ? ' · ' + RESULTADOS[m.resultado][0] : ''}</div></div></a>`;
}
const vacio = (i, t, extra = '') => `<div class="empty"><span class="i">${i}</span>${t}${extra}</div>`;

/* ───────────── pantallas ───────────── */
async function vSetup() {
  frame('Configuración inicial', 'Datos de la propiedad');
  $('#nav').classList.add('hide');
  const S = { ...CFG.propiedad, regInmueble: true, valorInmueble: '', descInmueble: '', fotos: [] };
  const R = () => {
    main.innerHTML = `<div class="card"><h2>Bienvenido</h2><p class="muted">Esta app guarda todo en este celular: el inventario, los movimientos, las fotos y las firmas. No usa internet ni servidores. Haga respaldos periódicos desde <b>Más → Respaldo</b>.</p></div>
    <div class="card" id="f"><h3>Propiedad que se controla</h3>
      ${fld('Nombre de la propiedad', 'nombre', S, { req: 1, ph: 'Ej.: Finca La Esperanza' })}
      ${fld('Dirección', 'direccion', S)}
      <div class="grid2">${fld('Ciudad / municipio', 'ciudad', S)}${fld('Teléfono de contacto', 'telefono', S, { type: 'tel' })}</div>
      ${fld('Propietario o responsable', 'responsable', S, { req: 1 })}
      <label class="row" style="margin-top:14px"><input type="checkbox" data-k="regInmueble" ${S.regInmueble ? 'checked' : ''}> <span>Registrar también el inmueble como un bien (con fotos de su estado actual)</span></label>
      <div id="inm" class="${S.regInmueble ? '' : 'hide'}">
        ${fld('Valor aproximado del inmueble', 'valorInmueble', S, { type: 'number', attrs: 'inputmode="decimal" min="0"' })}
        ${fld('Descripción del inmueble', 'descInmueble', S, { type: 'textarea', ph: 'Área, número de habitaciones, matrícula inmobiliaria, estado general…' })}
        <label class="f">Fotos del estado actual</label>${tiraFotos(S.fotos.map(f => f.id), { agregar: 1, quitar: 1 })}
      </div>
      <button class="block" id="ok" style="margin-top:16px">Comenzar</button></div>`;
    hydrate(main);
    $('#ok').onclick = guardar;
  };
  bindForm(main, S, k => { if (k === 'regInmueble') $('#inm').classList.toggle('hide', !S.regInmueble); });
  bindFotos(main, S, () => 'Inmueble', R);
  async function guardar() {
    if (!S.nombre?.trim() || !S.responsable?.trim()) return toast('Complete el nombre de la propiedad y el responsable');
    CFG.propiedad = { nombre: S.nombre.trim(), direccion: S.direccion || '', ciudad: S.ciudad || '', responsable: S.responsable.trim(), telefono: S.telefono || '', notas: '' };
    CFG.setupHecho = true; await saveCfg();
    if (S.regInmueble) {
      await crearBien({ tipoBien: 'inmueble', nombre: CFG.propiedad.nombre, categoria: 'Inmueble', ubicacion: 'Exterior', descripcion: S.descInmueble, cantidad: 1, unidad: 'und', valorUnit: num(S.valorInmueble), fechaIngreso: todayStr(), estadoFisico: 'Bueno', entrega: CFG.propiedad.responsable, recibe: CFG.propiedad.responsable, obs: 'Registro inicial del inmueble' }, S.fotos);
    }
    $('#nav').classList.remove('hide');
    toast('Propiedad configurada'); go('#/inicio', true);
  }
  R();
}

async function vInicio() {
  frame('Inventario de Bienes', CFG.propiedad.nombre, false, 'inicio');
  const items = await DB.all('items'), activos = items.filter(i => !i.baja);
  const movs = (await DB.all('movs')).sort((a, b) => b.n - a.n);
  const fuera = activos.filter(i => cantFuera(i) > 0), venc = activos.filter(i => vencidas(i).length), noEnc = activos.filter(i => i.alerta === 'no_encontrado'), pend = activos.filter(pendienteValidar);
  const total = activos.reduce((a, i) => a + valorItem(i), 0), inm = activos.filter(i => i.tipoBien === 'inmueble').reduce((a, i) => a + valorItem(i), 0);
  const respaldoDias = daysSince(CFG.ultimoRespaldo);
  main.innerHTML = `
    ${respaldoDias > 7 && movs.length ? `<div class="alert warn">⚠ ${CFG.ultimoRespaldo ? `Último respaldo hace ${Math.floor(respaldoDias)} días.` : 'Aún no ha hecho ningún respaldo.'} Si el celular se pierde o se borra la app, la información se pierde. <a href="#/respaldo">Hacer respaldo</a></div>` : ''}
    <div class="card"><div class="row between"><div class="grow"><h2>${esc(CFG.propiedad.nombre)}</h2><div class="small muted">${esc([CFG.propiedad.direccion, CFG.propiedad.ciudad].filter(Boolean).join(', '))}</div><div class="small muted">Responsable: ${esc(CFG.propiedad.responsable)}</div></div></div>
      <div style="margin-top:10px"><div class="small muted">Valor aproximado total</div><div style="font-size:1.6rem;font-weight:700">${fmtMoney(total)}</div>
      <div class="small muted">Bienes muebles ${fmtMoney(total - inm)}${inm ? ` · Inmueble ${fmtMoney(inm)}` : ''}</div></div></div>
    <div class="stats">
      <a class="stat" href="#/bienes"><div class="n">${activos.length}</div><div class="l">Bienes activos</div></a>
      <a class="stat ${fuera.length ? 'warn' : ''}" href="#/bienes?f=fuera"><div class="n">${fuera.length}</div><div class="l">Fuera de la propiedad</div></a>
      <a class="stat ${venc.length ? 'bad' : ''}" href="#/bienes?f=vencidos"><div class="n">${venc.length}</div><div class="l">Retorno vencido</div></a>
      <a class="stat ${noEnc.length ? 'bad' : pend.length ? 'warn' : 'ok'}" href="#/bienes?f=${noEnc.length ? 'noenc' : 'pend'}"><div class="n">${noEnc.length || pend.length}</div><div class="l">${noEnc.length ? 'No encontrados' : `Sin validar (> ${CFG.diasValidacion} días)`}</div></a>
    </div>
    <div class="actions"><button onclick="go('#/recorrido')">✓ Recorrido de verificación</button><button class="sec" onclick="go('#/reportes')">▤ Reporte e inventario</button>
      <button class="sec" onclick="go('#/registrar?tipo=salida')">↗ Registrar salida</button><button class="sec" onclick="go('#/registrar?tipo=entrada')">↘ Registrar entrada</button></div>
    ${fuera.length ? `<div class="sec-t"><h3>Bienes fuera ahora</h3></div><div class="list">${fuera.slice(0, 6).map(i => itemRow(i, null, ` <span class="small muted">· ${esc(i.fuera.map(f => f.persona).join(', '))}</span>`)).join('')}</div>` : ''}
    <div class="sec-t"><h3>Últimos movimientos</h3><a href="#/movimientos" class="small">Ver todos</a></div>
    <div class="list">${movs.slice(0, 8).map(m => movRow(m)).join('') || vacio('⇅', 'Aún no hay movimientos.<br>Registre el primer bien con el botón <b>＋ Registrar</b>.')}</div>`;
  hydrate(main);
}

async function vBienes() {
  frame('Bienes', '', false, 'bienes');
  const p = qs(); const S = { q: p.get('q') || '', f: p.get('f') || 'activos', cat: '', ubi: '', orden: 'nombre' };
  const items = await DB.all('items');
  const FIL = { activos: ['Activos', i => !i.baja], fuera: ['Fuera', i => !i.baja && cantFuera(i) > 0], vencidos: ['Vencidos', i => !i.baja && vencidas(i).length], pend: ['Sin validar', pendienteValidar], noenc: ['No encontrados', i => !i.baja && i.alerta === 'no_encontrado'], inm: ['Inmuebles', i => i.tipoBien === 'inmueble'], baja: ['De baja', i => i.baja], todos: ['Todos', () => true] };
  main.innerHTML = `<div class="search"><input id="q" type="search" placeholder="Buscar por nombre, código, serie, marca…" value="${esc(S.q)}"></div>
    <div class="chips" id="chips">${Object.entries(FIL).map(([k, v]) => `<button data-f="${k}" class="${k === S.f ? 'on' : ''}">${v[0]}</button>`).join('')}</div>
    <div class="grid2" style="margin-bottom:8px"><select id="cat"><option value="">Todas las categorías</option>${CFG.categorias.map(c => `<option>${esc(c)}</option>`).join('')}</select>
    <select id="ubi"><option value="">Todas las ubicaciones</option>${CFG.ubicaciones.map(c => `<option>${esc(c)}</option>`).join('')}</select></div>
    <div class="row between small muted" style="margin:4px 2px 8px"><span id="cnt"></span><select id="ord" style="width:auto;min-height:34px;padding:4px 8px"><option value="nombre">Nombre</option><option value="codigo">Código</option><option value="valor">Mayor valor</option><option value="reciente">Más reciente</option><option value="validacion">Validación más antigua</option></select></div>
    <div class="list" id="lst"></div>
    <button class="block" style="margin-top:14px" onclick="go('#/bien/nuevo')">＋ Registrar nuevo bien</button>`;
  const R = () => {
    const q = norm(S.q);
    let l = items.filter(FIL[S.f][1]).filter(i => (!S.cat || i.categoria === S.cat) && (!S.ubi || i.ubicacion === S.ubi))
      .filter(i => !q || norm([i.nombre, i.codigo, i.serie, i.marca, i.modelo, i.descripcion, i.categoria, i.ubicacion, ...(i.fuera || []).map(f => f.persona)].join(' ')).includes(q));
    const o = { nombre: (a, b) => a.nombre.localeCompare(b.nombre, 'es'), codigo: (a, b) => a.codigo.localeCompare(b.codigo, 'es', { numeric: true }), valor: (a, b) => valorItem(b) - valorItem(a), reciente: (a, b) => (b.actualizado || '').localeCompare(a.actualizado || ''), validacion: (a, b) => (ultimaRevision(a) || '').localeCompare(ultimaRevision(b) || '') }[S.orden];
    l.sort(o);
    $('#cnt').textContent = `${l.length} bien(es) · ${fmtMoney(l.reduce((a, i) => a + valorItem(i), 0))}`;
    $('#lst').innerHTML = l.map(i => itemRow(i)).join('') || vacio('▦', items.length ? 'Ningún bien coincide con el filtro.' : 'Aún no hay bienes registrados.');
    hydrate($('#lst'));
  };
  $('#q').oninput = e => { S.q = e.target.value; R(); };
  $('#chips').onclick = e => { const f = e.target.dataset.f; if (!f) return; S.f = f; $$('#chips button').forEach(b => b.classList.toggle('on', b.dataset.f === f)); R(); };
  $('#cat').onchange = e => { S.cat = e.target.value; R(); }; $('#ubi').onchange = e => { S.ubi = e.target.value; R(); }; $('#ord').onchange = e => { S.orden = e.target.value; R(); };
  R();
}

async function siguienteCodigo() { let c; const items = await DB.all('items'); const usados = new Set(items.map(i => i.codigo)); do { c = CFG.prefijo + String(CFG.siguiente).padStart(4, '0'); CFG.siguiente++; } while (usados.has(c)); await saveCfg(); return c; }
async function crearBien(d, fotos = []) {
  const it = { id: uid(), codigo: d.codigo || await siguienteCodigo(), tipoBien: d.tipoBien || 'mueble', nombre: d.nombre.trim(), categoria: d.categoria, ubicacion: d.ubicacion, descripcion: d.descripcion || '', marca: d.marca || '', modelo: d.modelo || '', serie: d.serie || '', cantidad: Math.max(1, Math.floor(num(d.cantidad) || 1)), unidad: d.unidad || 'und', valorUnit: num(d.valorUnit), fechaIngreso: d.fechaIngreso || todayStr(), estadoFisico: d.estadoFisico || 'Bueno', procedencia: d.procedencia || '', fotos: fotos.map(f => f.id), fuera: [], creado: nowISO(), baja: false };
  fotos.forEach(f => f.ref = { tipo: 'item', id: it.id, itemId: it.id });
  const m = { tipo: 'alta', itemId: it.id, fecha: d.fecha ? new Date(d.fecha).toISOString() : nowISO(), entrega: d.entrega, recibe: d.recibe, novedad: d.obs, estadoFisico: it.estadoFisico, destino: it.ubicacion, valor: it.valorUnit };
  const ops = [...opsPersona(d.entrega, '', '', 'Otro'), ...opsPersona(d.recibe, '', '', 'Cuidador')];
  return registrarMov(m, it, fotos, ops);
}

async function vBienForm(id) {
  const edit = id && id !== 'nuevo'; const old = edit ? await DB.get('items', id) : null;
  if (edit && !old) return go('#/bienes', true);
  frame(edit ? 'Editar bien' : 'Nuevo bien', edit ? old.codigo + ' · ' + old.nombre : 'Ingreso a la propiedad', true, 'registrar');
  const S = edit ? { ...old } : { tipoBien: qs().get('inm') ? 'inmueble' : 'mueble', nombre: '', categoria: '', ubicacion: '', cantidad: 1, unidad: 'und', valorUnit: '', fechaIngreso: todayStr(), fecha: toLocalInput(), estadoFisico: 'Bueno', entrega: '', recibe: '', obs: '', codigo: '', fotos: [] };
  if (edit) S.fotos = [];
  const R = () => {
    main.innerHTML = `${dlPersonas()}<div class="card" id="f">
      <label class="f">Tipo de bien</label><div class="seg"><button type="button" data-tb="mueble" class="${S.tipoBien !== 'inmueble' ? 'on' : ''}">Bien mueble / objeto</button><button type="button" data-tb="inmueble" class="${S.tipoBien === 'inmueble' ? 'on' : ''}">Inmueble</button></div>
      ${fld('Nombre del bien', 'nombre', S, { req: 1, ph: 'Ej.: Nevera Haceb 300 L' })}
      <div class="grid2">${fld('Categoría', 'categoria', S, { req: 1, opts: CFG.categorias })}${fld('Ubicación', 'ubicacion', S, { req: 1, opts: CFG.ubicaciones })}</div>
      ${fld('Descripción / características', 'descripcion', S, { type: 'textarea', ph: 'Color, material, medidas, accesorios, detalles que lo identifican…' })}
      <div class="grid2">${fld('Marca', 'marca', S)}${fld('Modelo', 'modelo', S)}${fld('N.º de serie / placa', 'serie', S, { full: 1 })}
      ${fld('Cantidad', 'cantidad', S, { type: 'number', req: 1, attrs: 'inputmode="numeric" min="1" step="1"' + (edit ? ' disabled' : ''), help: edit ? 'Para cambiar la cantidad use "Ajuste".' : '' })}${fld('Unidad', 'unidad', S, { opts: ['und', 'juego', 'par', 'caja', 'kg', 'm', 'm²', 'lote'], vacio: false })}
      ${fld('Valor unitario aproximado', 'valorUnit', S, { type: 'number', attrs: 'inputmode="decimal" min="0"' + (edit ? ' disabled' : ''), help: edit ? 'Para cambiar el valor use "Ajuste" o "Novedad".' : (num(S.cantidad) > 1 ? 'Total: ' + fmtMoney(num(S.valorUnit) * num(S.cantidad)) : '') })}
      ${fld('Estado físico', 'estadoFisico', S, { opts: ESTADOS, vacio: false })}
      ${fld('Fecha de ingreso a la propiedad', 'fechaIngreso', S, { type: 'date', req: 1 })}${fld('Procedencia', 'procedencia', S, { ph: 'Compra, herencia, traslado…' })}</div>
      ${edit ? '' : `<h3 style="margin-top:16px">Registro del ingreso</h3>
        <div class="grid2">${fld('Quién lo entrega / trae', 'entrega', S, { req: 1, list: 'dlp' })}${fld('Quién lo recibe', 'recibe', S, { req: 1, list: 'dlp' })}</div>
        ${fld('Fecha y hora del registro', 'fecha', S, { type: 'datetime-local' })}
        ${fld('Observaciones del ingreso', 'obs', S, { type: 'textarea' })}
        ${fld('Código de inventario', 'codigo', S, { ph: 'Automático: ' + CFG.prefijo + String(CFG.siguiente).padStart(4, '0'), help: 'Déjelo vacío para asignarlo automáticamente, o escriba el código de la etiqueta física.' })}
        <label class="f">Fotos del bien (registro) — se recomiendan al menos 2</label>${tiraFotos(S.fotos.map(f => f.id), { agregar: 1, quitar: 1 })}`}
      <button class="block" id="ok" style="margin-top:16px">${edit ? 'Guardar cambios' : 'Registrar ingreso'}</button></div>`;
    hydrate(main);
    $('#ok').onclick = guardar;
    $$('[data-tb]').forEach(b => b.onclick = () => { S.tipoBien = b.dataset.tb; if (S.tipoBien === 'inmueble' && !S.categoria) S.categoria = 'Inmueble'; R(); });
  };
  bindForm(main, S, k => { if (k === 'cantidad' || k === 'valorUnit') { const h = $('[data-k=valorUnit]')?.parentElement.querySelector('.small'); if (h && !edit) h.textContent = num(S.cantidad) > 1 ? 'Total: ' + fmtMoney(num(S.valorUnit) * num(S.cantidad)) : ''; } });
  bindFotos(main, S, () => S.nombre || 'Nuevo bien', R);
  async function guardar() {
    const falt = [];
    if (!S.nombre?.trim()) falt.push('nombre'); if (!S.categoria) falt.push('categoría'); if (!S.ubicacion) falt.push('ubicación'); if (!S.fechaIngreso) falt.push('fecha de ingreso');
    if (!edit) { if (!S.entrega?.trim()) falt.push('quién lo entrega'); if (!S.recibe?.trim()) falt.push('quién lo recibe'); }
    if (falt.length) return toast('Falta: ' + falt.join(', '));
    $('#ok').disabled = true;
    try {
      if (!edit) {
        if (S.codigo?.trim()) { const dup = (await DB.all('items')).find(i => norm(i.codigo) === norm(S.codigo)); if (dup) { $('#ok').disabled = false; return toast('Ese código ya existe: ' + dup.nombre); } }
        if (!S.fotos.length && !(await confirmar('Sin fotos', 'No agregó fotos del bien. Las fotos son la evidencia de su estado al ingresar. ¿Registrar de todas formas?', 'Registrar sin fotos'))) { $('#ok').disabled = false; return; }
        const r = await crearBien({ ...S, codigo: S.codigo?.trim() }, S.fotos);
        toast('Bien registrado: ' + r.item.codigo); go('#/bien/' + r.item.id, true);
      } else {
        const campos = { tipoBien: 'Tipo', nombre: 'Nombre', categoria: 'Categoría', ubicacion: 'Ubicación', descripcion: 'Descripción', marca: 'Marca', modelo: 'Modelo', serie: 'Serie', unidad: 'Unidad', estadoFisico: 'Estado', fechaIngreso: 'Fecha de ingreso', procedencia: 'Procedencia' };
        const cambios = [], nuevo = structuredClone(old);
        for (const [k, l] of Object.entries(campos)) { const a = String(old[k] ?? ''), b = String(S[k] ?? '').trim(); if (a !== b) { cambios.push(`${l}: «${a || '—'}» → «${b || '—'}»`); nuevo[k] = b; } }
        if (!cambios.length) { toast('Sin cambios'); return history.back(); }
        const motivo = await pedirTexto('Motivo del cambio', 'Explique brevemente por qué se corrigen los datos', '');
        if (motivo === null) { $('#ok').disabled = false; return; }
        await registrarMov({ tipo: 'edicion', itemId: id, fecha: nowISO(), detalle: cambios.join('\n'), motivo }, nuevo);
        toast('Cambios guardados'); go('#/bien/' + id, true);
      }
    } catch (e) { $('#ok').disabled = false; toast(e.message); }
  }
  R();
}

async function vBien(id) {
  const it = await DB.get('items', id); if (!it) return go('#/bienes', true);
  frame(it.nombre, it.codigo, true, 'bienes');
  const movs = (await DB.byIndex('movs', 'item', id)).sort((a, b) => b.n - a.n);
  const sit = sitOf(it);
  main.innerHTML = `
    <div class="hero">${it.fotos?.length ? `<img data-foto="${it.fotos[0]}" data-full="1" alt="">` : (it.tipoBien === 'inmueble' ? '⌂' : '▦')}</div>
    ${tiraFotos(it.fotos || [], { mini: 1 })}
    <div class="card"><div class="row between wrap"><h2 class="grow">${esc(it.nombre)}</h2><span class="mono">${esc(it.codigo)}</span></div>
      <div style="margin:6px 0 10px">${badgeSit(it)} <span class="badge b-off">${esc(it.estadoFisico || '')}</span>${it.tipoBien === 'inmueble' ? ' <span class="badge b-info">Inmueble</span>' : ''}</div>
      <dl class="kv"><dt>Valor aprox.</dt><dd>${fmtMoney(valorItem(it))}${num(it.cantidad) > 1 ? ` <span class="muted small">(${it.cantidad} × ${fmtMoney(it.valorUnit)})</span>` : ''}</dd>
      <dt>Cantidad</dt><dd>${it.cantidad} ${esc(it.unidad)}${cantFuera(it) ? ` · <b>${cantFuera(it)} fuera</b>` : ''}</dd>
      <dt>Categoría</dt><dd>${esc(it.categoria)}</dd><dt>Ubicación</dt><dd>${esc(it.ubicacion)}</dd>
      ${it.marca || it.modelo ? `<dt>Marca / modelo</dt><dd>${esc([it.marca, it.modelo].filter(Boolean).join(' · '))}</dd>` : ''}
      ${it.serie ? `<dt>Serie</dt><dd class="mono">${esc(it.serie)}</dd>` : ''}
      <dt>Fecha de ingreso</dt><dd>${fmtD(it.fechaIngreso)}</dd>${it.procedencia ? `<dt>Procedencia</dt><dd>${esc(it.procedencia)}</dd>` : ''}
      <dt>Última validación</dt><dd>${it.ultimaValidacion ? fmtDT(it.ultimaValidacion) + ' · ' + RESULTADOS[it.ultimoResultado]?.[0] : '<span class="muted">Nunca</span>'}</dd>
      ${it.descripcion ? `<dt>Descripción</dt><dd>${esc(it.descripcion).replace(/\n/g, '<br>')}</dd>` : ''}
      ${it.baja ? `<dt>Baja</dt><dd>${fmtDT(it.fechaBaja)} · ${esc(it.motivoBaja || '')}</dd>` : ''}</dl></div>
    ${(it.fuera || []).map(f => `<div class="alert ${f.retornoEsperado && f.retornoEsperado < todayStr() ? 'bad' : 'warn'}">↗ <b>${f.cantidad} und en poder de ${esc(f.persona)}</b> desde ${fmtDT(f.fecha)}${f.destino ? ' · Destino: ' + esc(f.destino) : ''}${f.retornoEsperado ? ` · Retorno esperado: <b>${fmtD(f.retornoEsperado)}</b>` : ' · Sin fecha de retorno'} <a href="#/registrar?tipo=entrada&item=${it.id}">Registrar entrada</a></div>`).join('')}
    ${it.alerta === 'no_encontrado' ? `<div class="alert bad">✕ En la última validación el bien <b>no fue encontrado</b>. Registre una validación nueva cuando aparezca, o dé de baja.</div>` : ''}
    ${it.baja ? '' : `<div class="actions">
      ${it.tipoBien !== 'inmueble' ? `<button class="warn" ${disponible(it) ? '' : 'disabled'} onclick="go('#/mov/nuevo?tipo=salida&item=${it.id}')">↗ Salida</button><button class="ok" ${cantFuera(it) ? '' : 'disabled'} onclick="go('#/mov/nuevo?tipo=entrada&item=${it.id}')">↘ Entrada</button>` : ''}
      <button onclick="go('#/mov/nuevo?tipo=validacion&item=${it.id}')">✓ Validar</button>
      <button class="sec" onclick="go('#/mov/nuevo?tipo=novedad&item=${it.id}')">! Novedad</button>
      ${it.tipoBien !== 'inmueble' ? `<button class="sec" onclick="go('#/mov/nuevo?tipo=traslado&item=${it.id}')">⇄ Traslado</button>` : ''}
      <button class="sec" id="addFotos">📷 Agregar fotos</button>
      <button class="sec" onclick="go('#/mov/nuevo?tipo=ajuste&item=${it.id}')">± Ajuste</button>
      <button class="sec" onclick="go('#/bien/${it.id}/editar')">✎ Editar datos</button>
      <button class="sec" style="color:var(--bad)" onclick="go('#/mov/nuevo?tipo=baja&item=${it.id}')">✕ Dar de baja</button></div>`}
    <button class="ghost block" style="margin-top:8px" id="hv">🖨 Hoja de vida del bien (imprimir / PDF)</button>
    <div class="sec-t"><h3>Historial de movimientos (${movs.length})</h3></div>
    <div class="tl">${movs.map(m => evento(m)).join('')}</div>`;
  hydrate(main);
  $('#hv').onclick = () => imprimirHojaVida(it, movs);
  const af = $('#addFotos'); if (af) af.onclick = async () => {
    const op = await dialogo('Agregar fotos al registro', '<p class="muted">Las fotos quedan en el historial y no se pueden borrar.</p>', [['Cancelar', 'sec', null], ['Galería', 'sec', 'g'], ['Cámara', '', 'c']]);
    if (!op) return;
    const fotos = op === 'c' ? await abrirCamara(it.codigo) : await galeria(it.codigo); if (!fotos.length) return;
    const nuevo = structuredClone(it); nuevo.fotos = [...(nuevo.fotos || []), ...fotos.map(f => f.id)];
    fotos.forEach(f => f.ref = { tipo: 'item', id: it.id, itemId: it.id });
    await registrarMov({ tipo: 'edicion', itemId: it.id, fecha: nowISO(), detalle: `Se agregaron ${fotos.length} foto(s) al registro del bien` }, nuevo, fotos);
    toast('Fotos agregadas'); vBien(id);
  };
}
function evento(m) {
  const p = [];
  if (m.entrega) p.push(`Entrega: <b>${esc(m.entrega)}</b>`); if (m.recibe) p.push(`${m.tipo === 'salida' ? 'Se lo lleva' : 'Recibe'}: <b>${esc(m.recibe)}</b>`);
  if (m.autoriza) p.push(`Autoriza: ${esc(m.autoriza)}`); if (m.cantidad && m.tipo !== 'alta') p.push(`Cant.: ${m.cantidad}`);
  if (m.origen && m.destino && m.origen !== m.destino) p.push(`${esc(m.origen)} → ${esc(m.destino)}`); else if (m.destino && m.tipo === 'salida') p.push(`Destino: ${esc(m.destino)}`);
  if (m.retornoEsperado) p.push(`Retorno: ${fmtD(m.retornoEsperado)}`); if (m.resultado) p.push(RESULTADOS[m.resultado][0]);
  if (m.estadoFisico && m.tipo !== 'alta') p.push(`Estado: ${esc(m.estadoFisico)}`);
  if (m.valorAnterior !== undefined) p.push(`Valor: ${fmtMoney(m.valorAnterior)} → ${fmtMoney(m.valor)}`); if (m.cantidadAnterior !== undefined) p.push(`Cantidad: ${m.cantidadAnterior} → ${m.nuevaCantidad}`);
  return `<div class="ev ${m.tipo} ${m.anuladoPor ? 'anulado' : ''}"><a class="box" href="#/movimiento/${m.id}"><div class="hd"><span>${tipoBadge(m.tipo)}${m.anuladoPor ? ' <span class="badge b-bad">Anulado</span>' : ''}</span><span class="small muted">N.º ${m.n}</span></div>
    <div class="small muted" style="margin:4px 0">${fmtDT(m.fecha)}</div>
    ${p.length ? `<div class="small">${p.join(' · ')}</div>` : ''}${m.motivo ? `<div class="small">Motivo: ${esc(m.motivo)}</div>` : ''}
    ${m.novedad ? `<div class="small" style="margin-top:3px">${esc(m.novedad)}</div>` : ''}${m.detalle ? `<div class="small muted" style="margin-top:3px;white-space:pre-line">${esc(m.detalle)}</div>` : ''}
    ${m.fotos?.length ? `<div style="margin-top:6px">${tiraFotos(m.fotos, { mini: 1 })}</div>` : ''}</a></div>`;
}

async function vRegistrar() {
  const tipo = qs().get('tipo'), itemQ = qs().get('item');
  if (tipo && itemQ) return go(`#/mov/nuevo?tipo=${tipo}&item=${itemQ}`, true);
  if (!tipo) {
    frame('Registrar', '¿Qué desea registrar?', false, 'registrar');
    const op = (t, i, l, d, h) => `<a href="${h}"><span class="i">${i}</span><div class="grow"><b>${l}</b><small>${d}</small></div><span class="muted">›</span></a>`;
    main.innerHTML = `<div class="card menu">
      ${op('', '★', 'Nuevo bien (ingreso)', 'Un objeto o bien que entra por primera vez a la propiedad', '#/bien/nuevo')}
      ${op('', '↗', 'Salida', 'Alguien se lleva un bien: quién, cuándo, para qué y hasta cuándo', '#/registrar?tipo=salida')}
      ${op('', '↘', 'Entrada / retorno', 'Regresa un bien que había salido', '#/registrar?tipo=entrada')}
      ${op('', '✓', 'Validar un bien', 'Verificar que está, dónde está y en qué estado', '#/registrar?tipo=validacion')}
      ${op('', '☑', 'Recorrido de verificación', 'Validar varios bienes seguidos por ubicación', '#/recorrido')}
      ${op('', '!', 'Novedad', 'Daño, reparación, mantenimiento, mejora (incluye el inmueble)', '#/registrar?tipo=novedad')}
      ${op('', '⇄', 'Traslado interno', 'Cambio de ubicación dentro de la propiedad', '#/registrar?tipo=traslado')}</div>`;
    return;
  }
  frame('Elija el bien', TIPOS[tipo]?.l, true, 'registrar');
  const items = await DB.all('items');
  const ok = { salida: i => !i.baja && i.tipoBien !== 'inmueble' && disponible(i) > 0, entrada: i => !i.baja && cantFuera(i) > 0, traslado: i => !i.baja && i.tipoBien !== 'inmueble', validacion: i => !i.baja, novedad: i => !i.baja }[tipo] || (i => !i.baja);
  const lista = items.filter(ok);
  main.innerHTML = `<div class="search"><input id="q" type="search" placeholder="Buscar bien…"></div><div class="list" id="lst"></div>`;
  const R = q => { q = norm(q); const l = lista.filter(i => !q || norm([i.nombre, i.codigo, i.serie, i.marca, i.ubicacion, ...(i.fuera || []).map(f => f.persona)].join(' ')).includes(q)).sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'));
    $('#lst').innerHTML = l.map(i => itemRow(i, `#/mov/nuevo?tipo=${tipo}&item=${i.id}`)).join('') || vacio('▦', tipo === 'entrada' ? 'No hay bienes fuera de la propiedad.' : 'No hay bienes disponibles para este registro.'); hydrate($('#lst')); };
  $('#q').oninput = e => R(e.target.value); R('');
}

async function vMovForm() {
  const p = qs(), id = p.get('item'), volver = p.get('volver');
  const it = await DB.get('items', id); if (!it) return go('#/registrar', true);
  const S = { tipo: p.get('tipo') || 'validacion', fecha: toLocalInput(), cantidad: 1, fotos: [], firma: null, estadoFisico: it.estadoFisico, resultado: p.get('res') || '', entrega: p.get('por') || '', recibe: '', autoriza: '', motivo: '', destino: '', retornoEsperado: '', novedad: '', recibeDoc: '', recibeTel: '', refN: it.fuera?.[0]?.n || '', valor: '', nuevaCantidad: '', tipoNov: '', validador: p.get('por') || '' };
  if (S.tipo === 'entrada' && it.fuera?.[0]) { S.entrega = it.fuera[0].persona; S.cantidad = it.fuera[0].cantidad; }
  const permitidos = t => !it.baja && ({ salida: it.tipoBien !== 'inmueble' && disponible(it) > 0, entrada: cantFuera(it) > 0, traslado: it.tipoBien !== 'inmueble', validacion: true, novedad: true, ajuste: true, baja: true }[t]);
  const R = () => {
    frame(TIPOS[S.tipo].l, it.codigo + ' · ' + it.nombre, true, 'registrar');
    const t = S.tipo, f = [];
    if (t === 'salida') {
      f.push(num(it.cantidad) > 1 ? fld(`Cantidad que sale (disponibles: ${disponible(it)})`, 'cantidad', S, { type: 'number', req: 1, attrs: `min="1" max="${disponible(it)}" inputmode="numeric"` }) : '');
      f.push(`<div class="grid2">${fld('Quién se lo lleva', 'recibe', S, { req: 1, list: 'dlp' })}${fld('Documento de identidad', 'recibeDoc', S, { attrs: 'inputmode="numeric"' })}${fld('Teléfono', 'recibeTel', S, { type: 'tel' })}${fld('Quién lo entrega (cuidador)', 'entrega', S, { req: 1, list: 'dlp' })}</div>`);
      f.push(fld('Quién autoriza la salida', 'autoriza', S, { list: 'dlp', ph: 'Ej.: el propietario' }));
      f.push(fld('Motivo de la salida', 'motivo', S, { req: 1, ph: 'Préstamo, reparación, uso temporal, venta…' }));
      f.push(`<div class="grid2">${fld('Destino', 'destino', S, { ph: 'A dónde se lleva' })}${fld('Fecha esperada de retorno', 'retornoEsperado', S, { type: 'date', help: 'Vacío = sin fecha de retorno' })}</div>`);
      f.push(fld('Estado en que sale', 'estadoFisico', S, { opts: ESTADOS, vacio: false }));
    } else if (t === 'entrada') {
      const ab = it.fuera || [];
      f.push(fld('Salida que se devuelve', 'refN', S, { req: 1, opts: ab.map(x => [x.n, `N.º ${x.n} · ${x.persona} · ${x.cantidad} und · ${fmtD(x.fecha)}`]), vacio: false }));
      const sel = ab.find(x => x.n === num(S.refN));
      f.push(sel && num(sel.cantidad) > 1 ? fld(`Cantidad que regresa (pendientes: ${sel.cantidad})`, 'cantidad', S, { type: 'number', req: 1, attrs: `min="1" max="${sel.cantidad}" inputmode="numeric"` }) : '');
      f.push(`<div class="grid2">${fld('Quién lo trae / entrega', 'entrega', S, { req: 1, list: 'dlp' })}${fld('Quién lo recibe', 'recibe', S, { req: 1, list: 'dlp' })}</div>`);
      f.push(`<div class="grid2">${fld('Estado en que regresa', 'estadoFisico', S, { opts: ESTADOS, vacio: false })}${fld('Ubicación donde queda', 'destino', S, { opts: CFG.ubicaciones, vacio: 'Igual: ' + it.ubicacion })}</div>`);
    } else if (t === 'traslado') {
      f.push(`<div class="alert info">Ubicación actual: <b>${esc(it.ubicacion)}</b></div>`);
      f.push(fld('Nueva ubicación', 'destino', S, { req: 1, opts: CFG.ubicaciones.filter(u => u !== it.ubicacion) }));
      f.push(`<div class="grid2">${fld('Quién lo traslada', 'entrega', S, { req: 1, list: 'dlp' })}${fld('Motivo', 'motivo', S)}</div>`);
    } else if (t === 'validacion') {
      f.push(`<label class="f">Resultado <span class="req">*</span></label><div class="seg">${Object.entries(RESULTADOS).map(([k, v]) => `<button type="button" data-res="${k}" class="${S.resultado === k ? 'on' : ''}">${v[0]}</button>`).join('')}</div>`);
      f.push(fld('Quién valida', 'entrega', S, { req: 1, list: 'dlp' }));
      if (S.resultado !== 'no_encontrado') f.push(`<div class="grid2">${fld('Estado físico observado', 'estadoFisico', S, { opts: ESTADOS, vacio: false })}${fld('Ubicación verificada', 'destino', S, { opts: CFG.ubicaciones, vacio: 'Igual: ' + it.ubicacion })}</div>`);
      if (cantFuera(it)) f.push(`<div class="alert warn">Este bien tiene ${cantFuera(it)} unidad(es) registradas fuera de la propiedad. Valide las ${disponible(it)} que deben estar aquí.</div>`);
    } else if (t === 'novedad') {
      f.push(fld('Tipo de novedad', 'tipoNov', S, { req: 1, opts: TIPOS_NOVEDAD }));
      f.push(fld('Reportada por', 'entrega', S, { req: 1, list: 'dlp' }));
      f.push(`<div class="grid2">${fld('Nuevo estado físico', 'estadoFisico', S, { opts: ESTADOS, vacio: false })}${fld('Nuevo valor unitario (opcional)', 'valor', S, { type: 'number', attrs: 'inputmode="decimal" min="0"', help: 'Actual: ' + fmtMoney(it.valorUnit) })}</div>`);
      f.push(fld('Costo asociado (opcional)', 'costo', S, { type: 'number', attrs: 'inputmode="decimal" min="0"', help: 'Ej.: valor de la reparación' }));
    } else if (t === 'ajuste') {
      f.push(`<div class="alert info">Actual: ${it.cantidad} ${esc(it.unidad)} × ${fmtMoney(it.valorUnit)}</div>`);
      f.push(`<div class="grid2">${fld('Nueva cantidad', 'nuevaCantidad', S, { type: 'number', attrs: 'min="1" inputmode="numeric"' })}${fld('Nuevo valor unitario', 'valor', S, { type: 'number', attrs: 'min="0" inputmode="decimal"' })}</div>`);
      f.push(`<div class="grid2">${fld('Responsable', 'entrega', S, { req: 1, list: 'dlp' })}${fld('Motivo del ajuste', 'motivo', S, { req: 1 })}</div>`);
    } else if (t === 'baja') {
      f.push(`<div class="alert bad">La baja retira el bien del inventario activo. Queda en el historial y no se puede deshacer (solo anular el registro).</div>`);
      f.push(`<div class="grid2">${fld('Motivo de la baja', 'motivo', S, { req: 1, opts: MOTIVOS_BAJA })}${fld('Responsable', 'entrega', S, { req: 1, list: 'dlp' })}${fld('Quién recibe (si aplica)', 'recibe', S, { list: 'dlp' })}${fld('Autoriza', 'autoriza', S, { list: 'dlp' })}</div>`);
    }
    f.push(fld('Fecha y hora del hecho', 'fecha', S, { type: 'datetime-local', req: 1, help: 'Se guarda además la hora real del registro.' }));
    f.push(fld(t === 'novedad' ? 'Descripción de la novedad' : 'Observaciones / novedades', 'novedad', S, { type: 'textarea', req: t === 'novedad' || (t === 'validacion' && S.resultado === 'con_novedad'), ph: 'Detalle lo que se observa: daños, faltantes, accesorios, condiciones…' }));
    const sugF = ['salida', 'entrada', 'novedad', 'baja'].includes(t) || (t === 'validacion' && S.resultado !== 'no_encontrado');
    f.push(`<label class="f">Fotos de la novedad / evidencia${sugF ? ' (recomendadas)' : ''}</label>${tiraFotos(S.fotos.map(x => x.id), { agregar: 1, quitar: 1 })}`);
    if (['salida', 'entrada', 'baja'].includes(t)) {
      const quien = t === 'salida' ? 'quien se lo lleva' : t === 'entrada' ? 'quien lo entrega' : 'el responsable';
      f.push(`<label class="f">Firma de ${quien}</label>${S.firma ? `<div class="row"><img src="${S.firma.url}" style="height:80px;background:#fff;border-radius:8px;border:1px solid var(--line)"><button type="button" class="sec" id="firmaBtn">Repetir</button></div>` : `<button type="button" class="ghost block" id="firmaBtn">✍ Capturar firma</button>`}`);
    }
    main.innerHTML = `${dlPersonas()}
      <a class="item" href="#/bien/${it.id}" style="margin-bottom:12px">${itemRow(it).replace(/^<a[^>]*>|<\/a>$/g, '')}</a>
      <div class="card" id="f"><label class="f">Tipo de registro</label>
        <div class="tipos">${['salida', 'entrada', 'validacion', 'novedad', 'traslado', 'ajuste', 'baja'].map(k => `<button type="button" data-tipo="${k}" class="${k === t ? 'on' : ''}" ${permitidos(k) ? '' : 'disabled'}><span class="i">${TIPOS[k].i}</span>${TIPOS[k].l}</button>`).join('')}</div>
        ${f.join('')}
        <button class="block ${t === 'baja' ? 'danger' : ''}" id="ok" style="margin-top:16px">Guardar ${TIPOS[t].l.toLowerCase()}</button></div>`;
    hydrate(main);
    $$('[data-tipo]').forEach(b => b.onclick = () => { S.tipo = b.dataset.tipo; R(); });
    $$('[data-res]').forEach(b => b.onclick = () => { S.resultado = b.dataset.res; R(); });
    const fb = $('#firmaBtn'); if (fb) fb.onclick = async () => { const fi = await capturarFirma('Firma de ' + (S.tipo === 'salida' ? (S.recibe || 'quien se lo lleva') : (S.entrega || 'quien entrega'))); if (fi) { S.firma = fi; R(); } };
    $('#ok').onclick = guardar;
  };
  bindForm(main, S, (k, e) => {
    if (k === 'refN' && S.tipo === 'entrada') { const x = it.fuera.find(z => z.n === num(S.refN)); if (x) { S.entrega = x.persona; S.cantidad = x.cantidad; } R(); }
    if ((k === 'recibe' || k === 'entrega') && e.type === 'change') { const pp = findPersona(S[k]); if (pp && k === 'recibe' && S.tipo === 'salida') { if (!S.recibeDoc) S.recibeDoc = pp.documento || ''; if (!S.recibeTel) S.recibeTel = pp.telefono || ''; const d = $('[data-k=recibeDoc]'), tt = $('[data-k=recibeTel]'); if (d) d.value = S.recibeDoc; if (tt) tt.value = S.recibeTel; } }
  });
  bindFotos(main, S, () => it.codigo + ' · ' + TIPOS[S.tipo].l, R);
  async function guardar() {
    const t = S.tipo, falt = [];
    const need = { salida: ['recibe', 'entrega', 'motivo'], entrada: ['refN', 'entrega', 'recibe'], traslado: ['destino', 'entrega'], validacion: ['resultado', 'entrega'], novedad: ['tipoNov', 'entrega', 'novedad'], ajuste: ['entrega', 'motivo'], baja: ['motivo', 'entrega'] }[t];
    const nombres = { recibe: 'quién recibe', entrega: t === 'validacion' ? 'quién valida' : 'quién entrega', motivo: 'motivo', refN: 'salida', destino: 'nueva ubicación', resultado: 'resultado', tipoNov: 'tipo de novedad', novedad: 'descripción' };
    need.forEach(k => { if (!String(S[k] ?? '').trim()) falt.push(nombres[k]); });
    if (t === 'validacion' && S.resultado === 'con_novedad' && !S.novedad.trim()) falt.push('descripción de la novedad');
    if (!S.fecha) falt.push('fecha');
    if (falt.length) return toast('Falta: ' + falt.join(', '));
    if (new Date(S.fecha) > new Date(Date.now() + 5 * 60000)) return toast('La fecha del hecho no puede ser futura');
    if (['salida', 'entrada'].includes(t) && !S.fotos.length && !(await confirmar('Sin fotos', `No agregó fotos de evidencia de la ${t}. ¿Guardar de todas formas?`, 'Guardar sin fotos'))) return;
    if (t === 'baja' && !(await confirmar('Confirmar baja', `¿Dar de baja «${esc(it.nombre)}»? Esta acción queda registrada y no se borra.`, 'Dar de baja', 'danger'))) return;
    const m = { tipo: t, itemId: it.id, fecha: new Date(S.fecha).toISOString(), entrega: S.entrega?.trim(), novedad: S.novedad?.trim(), estadoFisico: S.estadoFisico };
    if (t === 'salida') Object.assign(m, { cantidad: S.cantidad, recibe: S.recibe.trim(), recibeDoc: S.recibeDoc?.trim(), recibeTel: S.recibeTel?.trim(), autoriza: S.autoriza?.trim(), motivo: S.motivo.trim(), destino: S.destino?.trim(), retornoEsperado: S.retornoEsperado });
    if (t === 'entrada') Object.assign(m, { cantidad: S.cantidad, recibe: S.recibe.trim(), refN: num(S.refN), destino: S.destino });
    if (t === 'traslado') Object.assign(m, { destino: S.destino, motivo: S.motivo?.trim() });
    if (t === 'validacion') Object.assign(m, { resultado: S.resultado, destino: S.resultado === 'no_encontrado' ? '' : S.destino, estadoFisico: S.resultado === 'no_encontrado' ? '' : S.estadoFisico });
    if (t === 'novedad') Object.assign(m, { motivo: S.tipoNov, valor: S.valor === '' ? undefined : num(S.valor), costo: S.costo ? num(S.costo) : undefined });
    if (t === 'ajuste') Object.assign(m, { nuevaCantidad: S.nuevaCantidad === '' ? undefined : Math.floor(num(S.nuevaCantidad)), valor: S.valor === '' ? undefined : num(S.valor), motivo: S.motivo.trim() });
    if (t === 'baja') Object.assign(m, { motivo: S.motivo, recibe: S.recibe?.trim(), autoriza: S.autoriza?.trim() });
    const fotos = [...S.fotos];
    if (S.firma) { S.firma.ref = { tipo: 'firma', itemId: it.id }; m.firma = S.firma.id; fotos.push(S.firma); }
    const ops = [...opsPersona(m.entrega, '', '', t === 'salida' ? 'Cuidador' : 'Otro'), ...opsPersona(m.recibe, m.recibeDoc, m.recibeTel, 'Otro'), ...opsPersona(m.autoriza)];
    $('#ok').disabled = true;
    try {
      const r = await registrarMov(m, null, fotos, ops); // la firma se guarda aparte del listado de fotos
      toast(`${TIPOS[t].l} registrada · N.º ${r.mov.n}`);
      if (volver) go(decodeURIComponent(volver), true);
      else if (['salida', 'entrada', 'baja'].includes(t)) go('#/movimiento/' + r.mov.id + '?nuevo=1', true);
      else go('#/bien/' + it.id, true);
    } catch (e) { $('#ok').disabled = false; toast(e.message); await loadPersonas(); }
  }
  R();
}

async function vMov(id) {
  const m = await DB.get('movs', id); if (!m) return go('#/movimientos', true);
  const it = m.itemId ? await DB.get('items', m.itemId) : null;
  frame(TIPOS[m.tipo].l + ' N.º ' + m.n, m.snap ? m.snap.codigo + ' · ' + m.snap.nombre : '', true, 'movimientos');
  const ok = (await sha256(canon(m))) === m.hash;
  const anul = m.anuladoPor ? await DB.get('movs', m.anuladoPor) : null;
  const fotos = (m.fotos || []).filter(f => f !== m.firma);
  const kv = [['Fecha del hecho', fmtDT(m.fecha)], ['Registrado', fmtDT(m.registrado)], ['Entrega', m.entrega], [m.tipo === 'salida' ? 'Se lo lleva' : 'Recibe', m.recibe], ['Documento', m.recibeDoc], ['Teléfono', m.recibeTel], ['Autoriza', m.autoriza], ['Motivo', m.motivo], ['Cantidad', m.cantidad], ['Origen', m.origen], [m.tipo === 'salida' ? 'Destino' : 'Ubicación', m.destino], ['Retorno esperado', m.retornoEsperado && fmtD(m.retornoEsperado)], ['Resultado', m.resultado && RESULTADOS[m.resultado][0]], ['Estado físico', m.estadoFisico], ['Valor anterior', m.valorAnterior !== undefined && fmtMoney(m.valorAnterior)], ['Valor nuevo', m.valor !== undefined && m.tipo !== 'alta' && fmtMoney(m.valor)], ['Valor unitario', m.tipo === 'alta' && fmtMoney(m.valor)], ['Cantidad anterior', m.cantidadAnterior], ['Cantidad nueva', m.nuevaCantidad], ['Costo asociado', m.costo && fmtMoney(m.costo)], ['Salida que cierra', m.tipo === 'entrada' && 'N.º ' + m.refN], ['Anula el registro', m.tipo === 'anulacion' && m.refN && 'N.º ' + m.refN]].filter(x => x[1] !== undefined && x[1] !== '' && x[1] !== false && x[1] !== null);
  main.innerHTML = `
    ${qs().get('nuevo') ? `<div class="alert ok">✓ Registro guardado. Puede imprimir o guardar el comprobante en PDF.</div>` : ''}
    ${anul ? `<div class="alert bad">⊘ Este registro fue anulado (N.º ${anul.n}, ${fmtDT(anul.registrado)}): ${esc(anul.motivo || '')}</div>` : ''}
    <div class="card"><div class="row between"><span>${tipoBadge(m.tipo)}</span><span class="mono">N.º ${m.n}</span></div>
      ${it ? `<a href="#/bien/${it.id}" style="display:block;margin:8px 0;font-weight:600">${esc(it.nombre)} · ${esc(it.codigo)}</a>` : ''}
      <dl class="kv">${kv.map(([a, b]) => `<dt>${a}</dt><dd>${esc(b)}</dd>`).join('')}</dl>
      ${m.novedad ? `<label class="f">Observaciones</label><div style="white-space:pre-line">${esc(m.novedad)}</div>` : ''}
      ${m.detalle ? `<label class="f">Detalle</label><div style="white-space:pre-line" class="small">${esc(m.detalle)}</div>` : ''}</div>
    ${fotos.length ? `<div class="card"><h3>Fotos (${fotos.length})</h3>${tiraFotos(fotos)}</div>` : ''}
    ${m.firma ? `<div class="card"><h3>Firma</h3><img data-foto="${m.firma}" data-full="1" style="max-width:100%;height:110px;background:#fff;border-radius:8px"></div>` : ''}
    <div class="card flat small"><b>${ok ? '🔒 Registro íntegro' : '⚠ El contenido no coincide con su huella'}</b><div class="muted mono" style="word-break:break-all;margin-top:4px">Huella: ${m.hash}<br>Anterior: ${m.hashPrev}</div></div>
    <div class="actions"><button id="imp">🖨 Comprobante / PDF</button>${!m.anuladoPor && m.tipo !== 'anulacion' && m.tipo !== 'alta' ? `<button class="sec" style="color:var(--bad)" id="anu">⊘ Anular registro</button>` : ''}</div>`;
  hydrate(main);
  $('#imp').onclick = () => imprimirComprobante(m, it);
  const a = $('#anu'); if (a) a.onclick = async () => {
    const motivo = await pedirTexto('Anular registro N.º ' + m.n, 'Motivo de la anulación (obligatorio). El registro no se borra: queda marcado como anulado.', '', true);
    if (!motivo) return;
    const quien = await pedirTexto('Quién anula', 'Nombre de quien anula', CFG.propiedad.responsable); if (!quien) return;
    const orig = structuredClone(m);
    const r = await registrarMov({ tipo: 'anulacion', itemId: m.itemId, refN: m.n, motivo, entrega: quien, fecha: nowISO(), novedad: 'Si el registro anulado cambió la situación del bien, registre ahora el movimiento correcto.' }, null, [], []);
    orig.anuladoPor = r.mov.id; await DB.put('movs', orig);
    toast('Registro anulado'); vMov(id);
  };
}

async function vMovs() {
  frame('Movimientos', 'Registro de todos los movimientos', false, 'movimientos');
  const all = (await DB.all('movs')).sort((a, b) => b.n - a.n);
  const S = { f: 'todos', q: '', desde: '', hasta: '', lim: 80 };
  const F = { todos: ['Todos', () => true], salida: ['Salidas', m => m.tipo === 'salida'], entrada: ['Entradas', m => m.tipo === 'entrada'], alta: ['Ingresos', m => m.tipo === 'alta'], validacion: ['Validaciones', m => m.tipo === 'validacion'], novedad: ['Novedades', m => m.tipo === 'novedad'], otros: ['Otros', m => ['traslado', 'ajuste', 'baja', 'edicion', 'anulacion'].includes(m.tipo)] };
  main.innerHTML = `<div class="search"><input id="q" type="search" placeholder="Buscar bien, persona, motivo…"></div>
    <div class="chips" id="chips">${Object.entries(F).map(([k, v]) => `<button data-f="${k}" class="${k === S.f ? 'on' : ''}">${v[0]}</button>`).join('')}</div>
    <div class="grid2"><div><label class="f">Desde</label><input type="date" id="d1"></div><div><label class="f">Hasta</label><input type="date" id="d2"></div></div>
    <div class="row between small muted" style="margin:10px 2px"><span id="cnt"></span><a href="#" id="csv">Exportar CSV</a></div>
    <div class="list" id="lst"></div><button class="sec block hide" id="mas" style="margin-top:10px">Ver más</button>`;
  const filtrar = () => { const q = norm(S.q); return all.filter(F[S.f][1]).filter(m => (!S.desde || toLocalInput(m.fecha).slice(0, 10) >= S.desde) && (!S.hasta || toLocalInput(m.fecha).slice(0, 10) <= S.hasta)).filter(m => !q || norm([m.snap?.nombre, m.snap?.codigo, m.entrega, m.recibe, m.autoriza, m.motivo, m.novedad, m.destino, 'n' + m.n].join(' ')).includes(q)); };
  const R = () => { const l = filtrar(); $('#cnt').textContent = l.length + ' movimiento(s)'; $('#lst').innerHTML = l.slice(0, S.lim).map(m => movRow(m)).join('') || vacio('⇅', 'Sin movimientos para este filtro.'); $('#mas').classList.toggle('hide', l.length <= S.lim); hydrate($('#lst')); };
  $('#q').oninput = e => { S.q = e.target.value; R(); };
  $('#chips').onclick = e => { const f = e.target.dataset.f; if (!f) return; S.f = f; $$('#chips button').forEach(b => b.classList.toggle('on', b.dataset.f === f)); R(); };
  $('#d1').onchange = e => { S.desde = e.target.value; R(); }; $('#d2').onchange = e => { S.hasta = e.target.value; R(); };
  $('#mas').onclick = () => { S.lim += 80; R(); };
  $('#csv').onclick = e => { e.preventDefault(); exportarMovsCSV(filtrar()); };
  R();
}

async function vRecorrido() {
  const p = qs();
  const S = { ubi: p.get('ubi') ?? '', por: p.get('por') || '', ini: p.get('ini') };
  frame('Recorrido de verificación', S.ini ? (S.ubi || 'Todas las ubicaciones') : 'Validación por ubicación', true, 'registrar');
  const items = (await DB.all('items')).filter(i => !i.baja);
  if (!S.ini) {
    main.innerHTML = `${dlPersonas()}<div class="card"><p class="muted">Recorra la propiedad y marque cada bien como <b>Conforme</b>, <b>Con novedad</b> (pide foto y descripción) o <b>No encontrado</b>. Cada marca queda registrada como una validación con fecha y hora.</p>
      <label class="f">Ubicación a recorrer</label><select id="ubi"><option value="">Todas las ubicaciones (${items.length})</option>${CFG.ubicaciones.map(u => `<option value="${esc(u)}">${esc(u)} (${items.filter(i => i.ubicacion === u).length})</option>`).join('')}</select>
      <label class="f">Quién realiza la verificación <span class="req">*</span></label><input id="por" list="dlp" value="${esc(S.por)}">
      <button class="block" id="ok" style="margin-top:14px">Comenzar recorrido</button></div>`;
    $('#ok').onclick = () => { const por = $('#por').value.trim(); if (!por) return toast('Indique quién verifica'); go(`#/recorrido?ini=${Date.now()}&ubi=${encodeURIComponent($('#ubi').value)}&por=${encodeURIComponent(por)}`, true); };
    return;
  }
  const lista = items.filter(i => !S.ubi || i.ubicacion === S.ubi).sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'));
  const desde = new Date(num(S.ini)).toISOString();
  const hechos = new Map(); (await DB.all('movs')).filter(m => m.tipo === 'validacion' && m.registrado >= desde).forEach(m => hechos.set(m.itemId, m.resultado));
  const R = () => {
    const n = lista.filter(i => hechos.has(i.id)).length;
    main.innerHTML = `<div class="card"><div class="row between"><b>${n} de ${lista.length} verificados</b><span class="small muted">Por: ${esc(S.por)}</span></div><div class="progress" style="margin-top:8px"><i style="width:${lista.length ? n / lista.length * 100 : 0}%"></i></div>
      ${n === lista.length && lista.length ? `<div class="alert ok" style="margin:10px 0 0">✓ Recorrido completo. <a href="#/reportes">Ver reporte</a></div>` : ''}</div>
      <div class="list">${lista.map(i => { const h = hechos.get(i.id); return `<div class="card ${h ? 'done-' + (h === 'conforme' ? 'ok' : h === 'con_novedad' ? 'nov' : 'no') : ''}" style="padding:10px;margin:0">
        <div class="row"><div class="thumb">${i.fotos?.length ? `<img data-foto="${i.fotos[0]}">` : '▦'}</div><div class="grow"><div class="nm" style="font-weight:600">${esc(i.nombre)}</div><div class="small muted">${esc(i.codigo)} · ${esc(i.ubicacion)} · ${disponible(i)} ${esc(i.unidad)} deben estar${cantFuera(i) ? ` (${cantFuera(i)} fuera)` : ''}</div>
        ${h ? `<span class="badge ${RESULTADOS[h][1]}">${RESULTADOS[h][0]}</span>` : `<span class="small muted">Última validación: ${i.ultimaValidacion ? fmtD(i.ultimaValidacion) : 'nunca'}</span>`}</div></div>
        ${h ? '' : `<div class="vrow"><button class="ok" data-v="conforme" data-id="${i.id}">✓ Conforme</button><button class="warn" data-v="con_novedad" data-id="${i.id}">! Novedad</button><button class="danger" data-v="no_encontrado" data-id="${i.id}">✕ No está</button></div>`}</div>`; }).join('') || vacio('▦', 'No hay bienes en esta ubicación.')}</div>`;
    hydrate(main);
  };
  main.onclick = async e => {
    const b = e.target.closest('[data-v]'); if (!b) return;
    const id = b.dataset.id, v = b.dataset.v;
    if (v === 'con_novedad') return go(`#/mov/nuevo?tipo=validacion&res=con_novedad&item=${id}&por=${encodeURIComponent(S.por)}&volver=${encodeURIComponent(location.hash)}`);
    if (v === 'no_encontrado' && !(await confirmar('No encontrado', '¿Confirma que este bien no se encuentra en la propiedad?', 'Confirmar', 'danger'))) return;
    b.parentElement.querySelectorAll('button').forEach(x => x.disabled = true);
    try { await registrarMov({ tipo: 'validacion', itemId: id, resultado: v, entrega: S.por, fecha: nowISO(), novedad: v === 'no_encontrado' ? 'No encontrado durante el recorrido de verificación' : 'Verificado en recorrido' }, null, [], opsPersona(S.por)); hechos.set(id, v); R(); }
    catch (er) { toast(er.message); R(); }
  };
  // el formulario de novedad trae el parámetro "por": úselo como quién valida
  R();
}

async function vReportes() {
  frame('Reportes', 'Inventario y valor', true, 'mas');
  const items = await DB.all('items'), act = items.filter(i => !i.baja);
  const grp = k => { const g = {}; act.forEach(i => { const x = g[i[k]] ||= { n: 0, c: 0, v: 0 }; x.n++; x.c += num(i.cantidad); x.v += valorItem(i); }); return Object.entries(g).sort((a, b) => b[1].v - a[1].v); };
  const tabla = (titulo, rows) => `<div class="card"><h3>${titulo}</h3><table class="t"><thead><tr><th></th><th class="n">Bienes</th><th class="n">Unid.</th><th class="n">Valor</th></tr></thead><tbody>${rows.map(([k, x]) => `<tr><td>${esc(k)}</td><td class="n">${x.n}</td><td class="n">${x.c}</td><td class="n">${fmtMoney(x.v)}</td></tr>`).join('')}</tbody><tfoot><tr><td>Total</td><td class="n">${act.length}</td><td class="n">${act.reduce((a, i) => a + num(i.cantidad), 0)}</td><td class="n">${fmtMoney(act.reduce((a, i) => a + valorItem(i), 0))}</td></tr></tfoot></table></div>`;
  const fuera = act.filter(i => cantFuera(i)), noE = act.filter(i => i.alerta === 'no_encontrado'), pend = act.filter(pendienteValidar), bajas = items.filter(i => i.baja);
  main.innerHTML = `<div class="actions" style="margin-bottom:12px"><button id="pInv">🖨 Inventario completo (PDF)</button><button class="sec" id="pInvF">🖨 Inventario con fotos</button><button class="sec" id="cInv">⬇ Inventario CSV</button><button class="sec" id="cMov">⬇ Movimientos CSV</button></div>
    ${tabla('Por categoría', grp('categoria'))}${tabla('Por ubicación', grp('ubicacion'))}
    <div class="card"><h3>Fuera de la propiedad (${fuera.length})</h3>${fuera.length ? `<table class="t"><tbody>${fuera.flatMap(i => i.fuera.map(f => `<tr><td><a href="#/bien/${i.id}">${esc(i.nombre)}</a><div class="small muted">${esc(i.codigo)}</div></td><td>${esc(f.persona)}<div class="small muted">${f.cantidad} und · desde ${fmtD(f.fecha)}</div></td><td class="n">${f.retornoEsperado ? `<span class="${f.retornoEsperado < todayStr() ? 'badge b-bad' : ''}">${fmtD(f.retornoEsperado)}</span>` : '—'}</td></tr>`)).join('')}</tbody></table>` : '<p class="muted">Todo está en la propiedad.</p>'}</div>
    <div class="card"><h3>No encontrados en la última validación (${noE.length})</h3>${noE.map(i => itemRow(i)).join('') || '<p class="muted">Ninguno.</p>'}</div>
    <div class="card"><h3>Pendientes de validar · más de ${CFG.diasValidacion} días (${pend.length})</h3>${pend.length ? `<p class="small muted">${pend.slice(0, 30).map(i => esc(i.codigo + ' ' + i.nombre)).join(' · ')}${pend.length > 30 ? '…' : ''}</p><button class="sec" onclick="go('#/recorrido')">Hacer recorrido</button>` : '<p class="muted">Todo validado recientemente.</p>'}</div>
    <div class="card"><h3>Dados de baja (${bajas.length})</h3>${bajas.map(i => `<div class="small"><a href="#/bien/${i.id}">${esc(i.codigo)} ${esc(i.nombre)}</a> · ${fmtD(i.fechaBaja)} · ${esc(i.motivoBaja || '')}</div>`).join('') || '<p class="muted">Ninguno.</p>'}</div>`;
  hydrate(main);
  $('#pInv').onclick = () => imprimirInventario(items, false);
  $('#pInvF').onclick = () => imprimirInventario(items, true);
  $('#cInv').onclick = () => exportarInvCSV(items);
  $('#cMov').onclick = async () => exportarMovsCSV((await DB.all('movs')).sort((a, b) => a.n - b.n));
}

async function vPersonas() {
  frame('Personas', 'Cuidadores, propietarios y terceros', true, 'mas');
  await loadPersonas(); const items = await DB.all('items');
  const tiene = n => items.filter(i => (i.fuera || []).some(f => norm(f.persona) === norm(n))).length;
  main.innerHTML = `<button class="block" id="nueva" style="margin-bottom:12px">＋ Nueva persona</button>
    <div class="list">${PERSONAS.map(p => { const t = tiene(p.nombre); return `<a class="item" href="#/persona/${p.id}"><div class="thumb">👤</div><div class="grow"><div class="nm">${esc(p.nombre)}</div><div class="sub">${esc(p.rol || '')}${p.documento ? ' · ' + esc(p.documento) : ''}${p.telefono ? ' · ' + esc(p.telefono) : ''}</div>${t ? `<span class="badge b-warn">Tiene ${t} bien(es)</span>` : ''}</div></a>`; }).join('') || vacio('👤', 'Las personas se agregan solas al registrar movimientos, o puede crearlas aquí.')}</div>`;
  $('#nueva').onclick = () => editarPersona(null);
}
async function editarPersona(p) {
  const S = p ? { ...p } : { nombre: '', documento: '', telefono: '', rol: 'Cuidador', notas: '' };
  const r = await dialogo(p ? 'Editar persona' : 'Nueva persona', `<div id="pf">${fld('Nombre completo', 'nombre', S, { req: 1 })}<div class="grid2">${fld('Documento', 'documento', S)}${fld('Teléfono', 'telefono', S, { type: 'tel' })}</div>${fld('Rol', 'rol', S, { opts: ['Propietario', 'Cuidador', 'Familiar', 'Empleado', 'Proveedor / técnico', 'Otro'], vacio: false })}${fld('Notas', 'notas', S, { type: 'textarea' })}</div>`,
    [['Cancelar', 'sec', null], ['Guardar', '', m => { $$('[data-k]', m).forEach(e => S[e.dataset.k] = e.value.trim()); return S; }]]);
  if (!r) return;
  if (!r.nombre) return toast('El nombre es obligatorio');
  const dup = PERSONAS.find(x => norm(x.nombre) === norm(r.nombre) && x.id !== r.id); if (dup) return toast('Ya existe una persona con ese nombre');
  if (p && p.nombre !== r.nombre) toast('Nota: los movimientos anteriores conservan el nombre con que se registraron');
  r.id = r.id || uid(); r.creado = r.creado || nowISO(); await DB.put('personas', r); await loadPersonas(); route();
}
async function vPersona(id) {
  await loadPersonas(); const p = PERSONAS.find(x => x.id === id); if (!p) return go('#/personas', true);
  frame(p.nombre, p.rol, true, 'mas');
  const items = await DB.all('items'), movs = (await DB.all('movs')).filter(m => [m.entrega, m.recibe, m.autoriza].some(x => norm(x) === norm(p.nombre))).sort((a, b) => b.n - a.n);
  const enPoder = items.flatMap(i => (i.fuera || []).filter(f => norm(f.persona) === norm(p.nombre)).map(f => ({ i, f })));
  main.innerHTML = `<div class="card"><dl class="kv"><dt>Rol</dt><dd>${esc(p.rol)}</dd><dt>Documento</dt><dd>${esc(p.documento || '—')}</dd><dt>Teléfono</dt><dd>${p.telefono ? `<a href="tel:${esc(p.telefono)}">${esc(p.telefono)}</a>` : '—'}</dd>${p.notas ? `<dt>Notas</dt><dd>${esc(p.notas)}</dd>` : ''}</dl><button class="sec" style="margin-top:10px" id="ed">✎ Editar</button></div>
    <div class="sec-t"><h3>Bienes en su poder (${enPoder.length})</h3></div><div class="list">${enPoder.map(({ i, f }) => itemRow(i, null, ` <span class="small muted">· ${f.cantidad} und desde ${fmtD(f.fecha)}${f.retornoEsperado ? ' · retorno ' + fmtD(f.retornoEsperado) : ''}</span>`)).join('') || '<p class="muted">Ninguno.</p>'}</div>
    <div class="sec-t"><h3>Movimientos en que participa (${movs.length})</h3></div><div class="list">${movs.slice(0, 100).map(m => movRow(m)).join('')}</div>`;
  hydrate(main); $('#ed').onclick = () => editarPersona(p);
}

async function vCatalogos() {
  frame('Categorías y ubicaciones', '', true, 'mas');
  const items = await DB.all('items');
  const bloque = (k, t, campo) => `<div class="card"><h3>${t}</h3><div class="list" style="margin-top:8px">${CFG[k].map((c, i) => { const n = items.filter(x => x[campo] === c).length; return `<div class="row between" style="padding:6px 0;border-bottom:1px solid var(--line)"><span>${esc(c)} <span class="muted small">(${n})</span></span><span><button class="sec" style="min-height:34px;padding:4px 10px" data-ren="${k}:${i}">✎</button> <button class="sec" style="min-height:34px;padding:4px 10px" data-del="${k}:${i}" ${n ? 'disabled' : ''}>✕</button></span></div>`; }).join('')}</div><button class="ghost block" style="margin-top:10px" data-add="${k}">＋ Agregar</button></div>`;
  main.innerHTML = bloque('ubicaciones', 'Ubicaciones dentro de la propiedad', 'ubicacion') + bloque('categorias', 'Categorías (clasificación)', 'categoria') + '<p class="small muted">Solo se pueden eliminar las que no tienen bienes. Al renombrar, los bienes se actualizan y el cambio queda en su historial.</p>';
  main.onclick = async e => {
    const a = e.target.dataset;
    if (a.add) { const v = await pedirTexto('Agregar', 'Nombre'); if (v && !CFG[a.add].includes(v)) { CFG[a.add].push(v); await saveCfg(); vCatalogos(); } }
    if (a.del) { const [k, i] = a.del.split(':'); CFG[k].splice(+i, 1); await saveCfg(); vCatalogos(); }
    if (a.ren) {
      const [k, i] = a.ren.split(':'), viejo = CFG[k][+i], campo = k === 'ubicaciones' ? 'ubicacion' : 'categoria';
      const v = await pedirTexto('Renombrar', 'Nuevo nombre', viejo); if (!v || v === viejo) return;
      if (CFG[k].includes(v)) return toast('Ya existe');
      CFG[k][+i] = v; await saveCfg();
      for (const it of items.filter(x => x[campo] === viejo)) { const n = structuredClone(it); n[campo] = v; await registrarMov({ tipo: 'edicion', itemId: it.id, fecha: nowISO(), detalle: `${campo === 'ubicacion' ? 'Ubicación' : 'Categoría'}: «${viejo}» → «${v}» (renombrada en catálogo)` }, n); }
      vCatalogos();
    }
  };
}

function vMas() {
  frame('Más', '', false, 'mas');
  const op = (h, i, l, d) => `<a href="${h}"><span class="i">${i}</span><div class="grow"><b>${l}</b><small>${d}</small></div><span class="muted">›</span></a>`;
  main.innerHTML = `<div class="card menu">${op('#/reportes', '▤', 'Reportes', 'Inventario, valor, bienes fuera, PDF y CSV')}${op('#/recorrido', '☑', 'Recorrido de verificación', 'Validar bienes por ubicación')}${op('#/personas', '👤', 'Personas', 'Cuidadores, propietario y terceros')}${op('#/catalogos', '◫', 'Categorías y ubicaciones', 'Clasificación de los bienes')}${op('#/respaldo', '⛁', 'Respaldo y restauración', 'Copia de seguridad de toda la información')}${op('#/ajustes', '⚙', 'Ajustes', 'Propiedad, PIN, integridad del registro')}</div>
  <p class="small muted" style="text-align:center">Inventario de Bienes v${APP_VERSION} · Datos solo en este dispositivo</p>`;
}

async function vRespaldo() {
  frame('Respaldo', 'Copia de seguridad', true, 'mas');
  const [ni, nm, nf] = await Promise.all([DB.count('items'), DB.count('movs'), DB.count('fotos')]);
  let est = ''; try { const e = await navigator.storage.estimate(); est = ` · Espacio usado: ${(e.usage / 1048576).toFixed(1)} MB`; } catch {}
  main.innerHTML = `<div class="card"><h3>Contenido actual</h3><p class="muted">${ni} bienes · ${nm} movimientos · ${nf} fotos y firmas${est}</p>
    <p>Último respaldo: <b>${CFG.ultimoRespaldo ? fmtDT(CFG.ultimoRespaldo) : 'nunca'}</b></p></div>
    <div class="card"><h3>Hacer respaldo</h3><p class="muted small">Crea un archivo .json con toda la información, incluidas fotos y firmas. ${NATIVE ? 'Se guarda en la carpeta <b>Descargas</b> del celular.' : 'Se descarga en este equipo.'} Cópielo a otro lugar (computador, nube, USB) al menos una vez por semana.</p>
      <button class="block" id="exp">⛁ Crear respaldo completo</button><div id="prog" class="small muted" style="margin-top:8px"></div></div>
    <div class="card"><h3>Restaurar</h3><p class="muted small">Reemplaza TODA la información de este celular por la del archivo de respaldo. Úselo al cambiar de celular o tras reinstalar.</p>
      <button class="sec block" id="imp">Restaurar desde archivo…</button></div>`;
  $('#exp').onclick = async () => { $('#exp').disabled = true; try { const r = await exportarRespaldo(t => $('#prog').textContent = t); $('#prog').innerHTML = '✓ Guardado en ' + esc(r) + (NATIVE && AndroidBridge.shareLast ? '<br><button class="sec" style="margin-top:8px" onclick="AndroidBridge.shareLast()||toast(\'Copie el archivo desde Descargas/Inventario\')">Enviar copia (WhatsApp, correo, Drive, USB…)</button>' : ''); vRespaldoOk(); } catch (e) { $('#prog').textContent = 'Error: ' + e.message; } $('#exp').disabled = false; };
  $('#imp').onclick = importarRespaldo;
}
async function vRespaldoOk() { CFG.ultimoRespaldo = nowISO(); await saveCfg(); toast('Respaldo creado'); }

async function vAjustes() {
  frame('Ajustes', '', true, 'mas');
  const S = { ...CFG.propiedad, prefijo: CFG.prefijo, moneda: CFG.moneda, diasValidacion: CFG.diasValidacion };
  main.innerHTML = `<div class="card" id="f"><h3>Propiedad</h3>${fld('Nombre', 'nombre', S, { req: 1 })}${fld('Dirección', 'direccion', S)}<div class="grid2">${fld('Ciudad', 'ciudad', S)}${fld('Teléfono', 'telefono', S)}</div>${fld('Propietario / responsable', 'responsable', S)}${fld('Notas', 'notas', S, { type: 'textarea' })}
    <h3 style="margin-top:14px">Inventario</h3><div class="grid2">${fld('Prefijo de códigos', 'prefijo', S)}${fld('Moneda', 'moneda', S, { opts: ['COP', 'USD', 'EUR', 'MXN', 'PEN', 'CLP', 'ARS'], vacio: false })}${fld('Validar cada (días)', 'diasValidacion', S, { type: 'number', attrs: 'min="1"' })}</div>
    <button class="block" id="ok" style="margin-top:14px">Guardar</button></div>
    <div class="card"><h3>Bloqueo con PIN</h3><p class="muted small">${CFG.pinHash ? 'El PIN está activo: se pide al abrir la app y tras 2 minutos en segundo plano.' : 'Proteja la app con un PIN de 4 a 6 dígitos.'}</p><div class="row"><button class="sec grow" id="pin">${CFG.pinHash ? 'Cambiar PIN' : 'Activar PIN'}</button>${CFG.pinHash ? '<button class="sec grow" id="nopin">Quitar PIN</button>' : ''}</div></div>
    <div class="card"><h3>Integridad del registro</h3><p class="muted small">Cada movimiento lleva una huella SHA-256 encadenada con el anterior. Si alguien altera o borra un registro, la verificación lo detecta.</p><button class="sec block" id="ver">🔒 Verificar integridad</button><div id="verr" class="small" style="margin-top:8px"></div></div>
    <div class="card"><h3>Almacenamiento</h3><p class="muted small" id="alm">…</p></div>`;
  bindForm($('#f'), S);
  $('#ok').onclick = async () => { if (!S.nombre?.trim()) return toast('El nombre es obligatorio'); CFG.propiedad = { nombre: S.nombre.trim(), direccion: S.direccion, ciudad: S.ciudad, responsable: S.responsable, telefono: S.telefono, notas: S.notas }; CFG.prefijo = S.prefijo || 'BN-'; CFG.moneda = S.moneda; CFG.diasValidacion = Math.max(1, num(S.diasValidacion) || 30); await saveCfg(); toast('Guardado'); frame('Ajustes', '', true, 'mas'); };
  $('#pin').onclick = definirPIN;
  const np = $('#nopin'); if (np) np.onclick = async () => { if (await confirmar('Quitar PIN', '¿Quitar el bloqueo con PIN?')) { CFG.pinHash = null; await saveCfg(); vAjustes(); } };
  $('#ver').onclick = async () => { $('#verr').textContent = 'Verificando…'; const r = await verificarCadena(); $('#verr').innerHTML = r.errores.length ? `<div class="alert bad">${r.errores.map(esc).join('<br>')}</div>` : `<div class="alert ok">✓ ${r.total} movimientos verificados. La cadena está íntegra.</div>`; };
  try { const e = await navigator.storage.estimate(); const pers = navigator.storage.persisted ? await navigator.storage.persisted() : null; $('#alm').textContent = `Usado ${(e.usage / 1048576).toFixed(1)} MB${e.quota ? ' de ' + (e.quota / 1073741824).toFixed(1) + ' GB disponibles' : ''}${pers === null ? '' : pers ? ' · almacenamiento persistente' : ''}.`; } catch { $('#alm').textContent = 'No disponible'; }
}

/* ───────────── PIN ───────────── */
async function definirPIN() {
  const a = await dialogo('Nuevo PIN', `<input id="p1" type="password" inputmode="numeric" maxlength="6" placeholder="4 a 6 dígitos"><input id="p2" type="password" inputmode="numeric" maxlength="6" placeholder="Repita el PIN" style="margin-top:8px">`, [['Cancelar', 'sec', null], ['Guardar', '', m => [$('#p1', m).value, $('#p2', m).value]]]);
  if (!a) return; if (!/^\d{4,6}$/.test(a[0])) return toast('El PIN debe tener de 4 a 6 dígitos'); if (a[0] !== a[1]) return toast('Los PIN no coinciden');
  CFG.pinSalt = uid(); CFG.pinHash = await sha256(CFG.pinSalt + a[0]); await saveCfg(); toast('PIN activado'); vAjustes();
}
let bloqueado = false;
function bloquear() {
  if (!CFG.pinHash || bloqueado) return; bloqueado = true;
  const L = document.createElement('div'); L.className = 'lock'; let v = '';
  L.innerHTML = `<div style="font-size:2.2rem">🔒</div><b>${esc(CFG.propiedad.nombre || 'Inventario')}</b><div class="dots">${'<i></i>'.repeat(6)}</div><div class="pad">${[1, 2, 3, 4, 5, 6, 7, 8, 9, '', 0, '⌫'].map(k => k === '' ? '<span></span>' : `<button data-k="${k}">${k}</button>`).join('')}</div><button class="sec" id="lok" style="background:rgba(255,255,255,.2);color:#fff">Entrar</button>`;
  document.body.appendChild(L);
  const pinta = () => $$('.dots i', L).forEach((d, i) => d.classList.toggle('f', i < v.length));
  const probar = async () => { if (await sha256(CFG.pinSalt + v) === CFG.pinHash) { L.remove(); bloqueado = false; } else if (v.length >= 4) { v = ''; pinta(); toast('PIN incorrecto'); } };
  L.onclick = async e => { const k = e.target.dataset.k; if (e.target.id === 'lok') return probar(); if (k === undefined) return; v = k === '⌫' ? v.slice(0, -1) : (v + k).slice(0, 6); pinta(); if (v.length >= 4 && await sha256(CFG.pinSalt + v) === CFG.pinHash) { L.remove(); bloqueado = false; } };
}
let ocultoDesde = 0;
document.addEventListener('visibilitychange', () => { if (document.hidden) ocultoDesde = Date.now(); else if (ocultoDesde && Date.now() - ocultoDesde > 120000) bloquear(); });

/* ───────────── archivos: guardar / imprimir ───────────── */
async function abrirEscritor(nombre, mime) {
  if (NATIVE && AndroidBridge.beginFile) {
    if (!AndroidBridge.beginFile(nombre, mime)) throw new Error('No se pudo crear el archivo en Descargas');
    return { write: async s => { for (let i = 0; i < s.length; i += 512 * 1024) { if (!AndroidBridge.appendText(s.slice(i, i + 512 * 1024))) throw new Error('Error escribiendo el archivo'); await sleep(0); } }, close: async () => AndroidBridge.endFile() || ('Descargas/' + nombre) };
  }
  const partes = [];
  return { write: async s => partes.push(s), close: async () => { const b = new Blob(partes, { type: mime }); const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = nombre; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 30000); return nombre + ' (descargas)'; } };
}
async function guardarTexto(nombre, mime, texto) { const w = await abrirEscritor(nombre, mime); await w.write(texto); const r = await w.close(); toast('Guardado en ' + r, 4000); return r; }
const stamp = () => toLocalInput().replace(/[-:T]/g, '').slice(0, 12);
const slug = s => norm(s).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 30) || 'propiedad';
function csv(rows) { return '﻿' + rows.map(r => r.map(v => { v = v === undefined || v === null ? '' : String(v); return /[;"\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }).join(';')).join('\r\n'); }
function exportarInvCSV(items) {
  const rows = [['Código', 'Nombre', 'Tipo', 'Categoría', 'Ubicación', 'Descripción', 'Marca', 'Modelo', 'Serie', 'Cantidad', 'Unidad', 'Valor unitario', 'Valor total', 'Estado físico', 'Situación', 'Unid. fuera', 'En poder de', 'Retorno esperado', 'Fecha ingreso', 'Última validación', 'Resultado validación', 'Fotos']];
  items.sort((a, b) => a.codigo.localeCompare(b.codigo, 'es', { numeric: true })).forEach(i => rows.push([i.codigo, i.nombre, i.tipoBien, i.categoria, i.ubicacion, i.descripcion, i.marca, i.modelo, i.serie, i.cantidad, i.unidad, num(i.valorUnit), valorItem(i), i.estadoFisico, SIT[sitOf(i)][0], cantFuera(i), (i.fuera || []).map(f => f.persona).join(', '), (i.fuera || []).map(f => f.retornoEsperado).filter(Boolean).join(', '), i.fechaIngreso, i.ultimaValidacion ? toLocalInput(i.ultimaValidacion).replace('T', ' ') : '', i.ultimoResultado ? RESULTADOS[i.ultimoResultado][0] : '', (i.fotos || []).length]));
  return guardarTexto(`inventario-${slug(CFG.propiedad.nombre)}-${stamp()}.csv`, 'text/csv', csv(rows));
}
function exportarMovsCSV(movs) {
  const rows = [['N.º', 'Tipo', 'Fecha del hecho', 'Registrado', 'Código', 'Bien', 'Cantidad', 'Entrega', 'Recibe / se lo lleva', 'Documento', 'Teléfono', 'Autoriza', 'Motivo', 'Origen', 'Destino', 'Retorno esperado', 'Resultado', 'Estado físico', 'Observaciones', 'Detalle', 'Fotos', 'Firma', 'Anulado', 'Huella SHA-256']];
  movs.forEach(m => rows.push([m.n, TIPOS[m.tipo]?.l, toLocalInput(m.fecha).replace('T', ' '), toLocalInput(m.registrado).replace('T', ' '), m.snap?.codigo, m.snap?.nombre, m.cantidad, m.entrega, m.recibe, m.recibeDoc, m.recibeTel, m.autoriza, m.motivo, m.origen, m.destino, m.retornoEsperado, m.resultado ? RESULTADOS[m.resultado][0] : '', m.estadoFisico, m.novedad, m.detalle, (m.fotos || []).filter(f => f !== m.firma).length, m.firma ? 'Sí' : '', m.anuladoPor ? 'Sí' : '', m.hash]));
  return guardarTexto(`movimientos-${slug(CFG.propiedad.nombre)}-${stamp()}.csv`, 'text/csv', csv(rows));
}
async function imprimir(html, titulo) {
  const P = $('#print'); P.innerHTML = html;
  const imgs = $$('img[data-foto]', P);
  await Promise.all(imgs.map(async i => { i.src = await fotoURL(i.dataset.foto, i.dataset.full === '1'); }));
  await Promise.all($$('img', P).map(i => i.complete ? 0 : new Promise(r => { i.onload = i.onerror = r; })));
  await sleep(150);
  if (NATIVE && AndroidBridge.print) AndroidBridge.print(titulo); else window.print();
}
const cabecera = t => `<h1>${esc(t)}</h1><div class="meta">${esc(CFG.propiedad.nombre)} · ${esc([CFG.propiedad.direccion, CFG.propiedad.ciudad].filter(Boolean).join(', '))} · Responsable: ${esc(CFG.propiedad.responsable)}<br>Generado: ${fmtDT(nowISO())} · Inventario de Bienes v${APP_VERSION}</div>`;
function imprimirInventario(items, conFotos) {
  const act = items.filter(i => !i.baja).sort((a, b) => a.ubicacion.localeCompare(b.ubicacion, 'es') || a.codigo.localeCompare(b.codigo, 'es', { numeric: true }));
  const total = act.reduce((a, i) => a + valorItem(i), 0);
  let h = cabecera('Inventario de bienes') + `<p><b>${act.length}</b> bienes activos · Valor aproximado total: <b>${fmtMoney(total)}</b></p>`;
  const ubis = [...new Set(act.map(i => i.ubicacion))];
  for (const u of ubis) {
    const l = act.filter(i => i.ubicacion === u);
    h += `<h2>${esc(u)} — ${fmtMoney(l.reduce((a, i) => a + valorItem(i), 0))}</h2><table><thead><tr>${conFotos ? '<th>Foto</th>' : ''}<th>Código</th><th>Bien</th><th>Categoría</th><th class="n">Cant.</th><th>Estado</th><th>Situación</th><th class="n">Valor</th></tr></thead><tbody>${l.map(i => `<tr>${conFotos ? `<td>${i.fotos?.length ? `<img data-foto="${i.fotos[0]}" style="width:80px;height:60px;object-fit:cover">` : ''}</td>` : ''}<td>${esc(i.codigo)}</td><td><b>${esc(i.nombre)}</b>${i.marca || i.serie ? `<br><small>${esc([i.marca, i.modelo, i.serie && 'S/N ' + i.serie].filter(Boolean).join(' · '))}</small>` : ''}</td><td>${esc(i.categoria)}</td><td class="n">${i.cantidad}</td><td>${esc(i.estadoFisico)}</td><td>${SIT[sitOf(i)][0]}${cantFuera(i) ? `<br><small>${esc(i.fuera.map(f => f.cantidad + ' con ' + f.persona).join('; '))}</small>` : ''}${i.alerta ? '<br><small>NO ENCONTRADO</small>' : ''}</td><td class="n">${fmtMoney(valorItem(i))}</td></tr>`).join('')}</tbody></table>`;
  }
  h += `<div class="firmas"><div>Firma del responsable / propietario</div><div>Firma del cuidador</div></div>`;
  return imprimir(h, 'Inventario ' + CFG.propiedad.nombre);
}
function imprimirComprobante(m, it) {
  const fotos = (m.fotos || []).filter(f => f !== m.firma);
  const filas = [['Bien', it ? `${it.codigo} · ${it.nombre}` : m.snap?.nombre], ['Serie', it?.serie], ['Fecha del hecho', fmtDT(m.fecha)], ['Registrado', fmtDT(m.registrado)], ['Cantidad', m.cantidad], ['Entrega', m.entrega], [m.tipo === 'salida' ? 'Se lo lleva' : 'Recibe', m.recibe], ['Documento', m.recibeDoc], ['Teléfono', m.recibeTel], ['Autoriza', m.autoriza], ['Motivo', m.motivo], ['Origen', m.origen], ['Destino', m.destino], ['Retorno esperado', m.retornoEsperado && fmtD(m.retornoEsperado)], ['Resultado', m.resultado && RESULTADOS[m.resultado][0]], ['Estado físico', m.estadoFisico], ['Valor aprox.', it && fmtMoney(m.cantidad ? num(it.valorUnit) * num(m.cantidad) : valorItem(it))], ['Observaciones', m.novedad], ['Detalle', m.detalle]].filter(x => x[1] !== undefined && x[1] !== '' && x[1] !== null && x[1] !== false);
  const h = cabecera(`Comprobante de ${TIPOS[m.tipo].l.toLowerCase()} N.º ${m.n}`) + (m.anuladoPor ? '<p><b>REGISTRO ANULADO</b></p>' : '') +
    `<table style="margin-top:10px"><tbody>${filas.map(([a, b]) => `<tr><th style="width:30%">${a}</th><td>${esc(b).replace(/\n/g, '<br>')}</td></tr>`).join('')}</tbody></table>
    ${fotos.length ? `<h2>Evidencia fotográfica</h2>${fotos.map(f => `<img class="ph" data-foto="${f}" data-full="1">`).join('')}` : ''}
    <div class="firmas"><div>${m.firma ? `<img class="sigimg" data-foto="${m.firma}" data-full="1"><br>` : '<br><br><br>'}${esc(m.tipo === 'salida' ? m.recibe : m.entrega || '')}<br>${m.tipo === 'salida' ? 'Recibe y se lleva el bien' : 'Entrega'}${m.recibeDoc ? ' · Doc. ' + esc(m.recibeDoc) : ''}</div><div><br><br><br>${esc(m.tipo === 'salida' ? m.entrega : m.recibe || '')}<br>${m.tipo === 'salida' ? 'Entrega (cuidador)' : 'Recibe'}</div></div>
    <p class="meta" style="margin-top:16px">Huella SHA-256: ${m.hash}</p>`;
  return imprimir(h, `Comprobante ${m.n}`);
}
function imprimirHojaVida(it, movs) {
  const h = cabecera(`Hoja de vida · ${it.codigo} ${it.nombre}`) +
    `<table style="margin-top:10px"><tbody>${[['Categoría', it.categoria], ['Ubicación', it.ubicacion], ['Marca / modelo', [it.marca, it.modelo].filter(Boolean).join(' · ')], ['Serie', it.serie], ['Cantidad', it.cantidad + ' ' + it.unidad], ['Valor aproximado', fmtMoney(valorItem(it))], ['Estado físico', it.estadoFisico], ['Situación', SIT[sitOf(it)][0]], ['Fecha de ingreso', fmtD(it.fechaIngreso)], ['Descripción', it.descripcion]].filter(x => x[1]).map(([a, b]) => `<tr><th style="width:30%">${a}</th><td>${esc(b)}</td></tr>`).join('')}</tbody></table>
    ${it.fotos?.length ? `<h2>Fotos del registro</h2>${it.fotos.slice(0, 8).map(f => `<img class="ph" data-foto="${f}" data-full="1">`).join('')}` : ''}
    <h2>Historial (${movs.length} movimientos)</h2><table><thead><tr><th>N.º</th><th>Fecha</th><th>Tipo</th><th>Personas</th><th>Detalle</th></tr></thead><tbody>${[...movs].reverse().map(m => `<tr><td>${m.n}${m.anuladoPor ? ' (anulado)' : ''}</td><td>${fmtDT(m.fecha)}</td><td>${TIPOS[m.tipo].l}</td><td>${esc([m.entrega && 'Entrega: ' + m.entrega, m.recibe && 'Recibe: ' + m.recibe, m.autoriza && 'Autoriza: ' + m.autoriza].filter(Boolean).join('; '))}</td><td>${esc([m.motivo, m.resultado && RESULTADOS[m.resultado][0], m.destino && 'Destino: ' + m.destino, m.retornoEsperado && 'Retorno: ' + fmtD(m.retornoEsperado), m.novedad, m.detalle].filter(Boolean).join(' · '))}${m.fotos?.length ? ` · ${m.fotos.length} foto(s)` : ''}</td></tr>`).join('')}</tbody></table>`;
  return imprimir(h, 'Hoja de vida ' + it.codigo);
}

/* ───────────── respaldo ───────────── */
function blobToB64(b) { return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1] || ''); r.onerror = rej; r.readAsDataURL(b); }); }
function b64ToBlob(b64, type = 'image/jpeg') { const s = atob(b64), u = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return new Blob([u], { type }); }
async function exportarRespaldo(prog = () => {}) {
  const [items, movs, personas, config, fotos] = await Promise.all(['items', 'movs', 'personas', 'config'].map(s => DB.all(s)).concat(DB.req('fotos', 'readonly', s => s.getAllKeys())));
  const nombre = `respaldo-inventario-${slug(CFG.propiedad.nombre)}-${stamp()}.json`;
  const w = await abrirEscritor(nombre, 'application/json');
  const cfgCopia = config.map(c => c.k === 'cfg' ? { ...c, v: { ...c.v, ultimoRespaldo: nowISO() } } : c);
  await w.write(`{"app":"inventario-bienes","formato":1,"version":"${APP_VERSION}","fecha":"${nowISO()}","propiedad":${JSON.stringify(CFG.propiedad.nombre)},\n"config":${JSON.stringify(cfgCopia)},\n"personas":${JSON.stringify(personas)},\n"items":${JSON.stringify(items)},\n"movs":${JSON.stringify(movs)},\n"fotos":[`);
  for (let i = 0; i < fotos.length; i++) {
    const f = await DB.get('fotos', fotos[i]);
    const o = { id: f.id, w: f.w, h: f.h, fecha: f.fecha, ref: f.ref, mime: f.blob.type || 'image/jpeg', data: await blobToB64(f.blob), thumb: f.thumb && f.thumb !== f.blob ? await blobToB64(f.thumb) : null };
    await w.write((i ? ',\n' : '\n') + JSON.stringify(o));
    if (i % 10 === 0) prog(`Fotos ${i + 1} de ${fotos.length}…`);
  }
  await w.write('\n]}\n');
  return await w.close();
}
async function importarRespaldo() {
  const [file] = await pickFiles('#fileJson'); if (!file) return;
  let d; try { d = JSON.parse(await file.text()); } catch { return toast('El archivo no es un respaldo válido'); }
  if (d.app !== 'inventario-bienes' || !Array.isArray(d.items) || !Array.isArray(d.movs)) return toast('El archivo no es un respaldo de esta app');
  if (!(await confirmar('Restaurar respaldo', `Respaldo de «${esc(d.propiedad || '')}» del ${fmtDT(d.fecha)}: ${d.items.length} bienes, ${d.movs.length} movimientos, ${d.fotos?.length || 0} fotos.<br><br><b>Se reemplazará toda la información actual de este celular.</b>`, 'Reemplazar todo', 'danger'))) return;
  toast('Restaurando…', 1500);
  await DB.clearAll();
  const ops = [...d.config.map(c => ['config', c]), ...d.personas.map(p => ['personas', p]), ...d.items.map(i => ['items', i]), ...d.movs.map(m => ['movs', m])];
  await DB.write(ops);
  const fotos = d.fotos || [];
  for (let i = 0; i < fotos.length; i += 25) {
    await DB.write(fotos.slice(i, i + 25).map(f => { const blob = b64ToBlob(f.data, f.mime); return ['fotos', { id: f.id, w: f.w, h: f.h, fecha: f.fecha, ref: f.ref, blob, thumb: f.thumb ? b64ToBlob(f.thumb) : blob }]; }));
  }
  URLS.clear(); await loadCfg(); await loadPersonas();
  const v = await verificarCadena();
  await dialogo('Restauración completa', `<p>${d.items.length} bienes, ${d.movs.length} movimientos y ${fotos.length} fotos restaurados.</p><p>${v.errores.length ? '⚠ La verificación de integridad encontró diferencias: ' + esc(v.errores.slice(0, 3).join('; ')) : '🔒 La cadena de integridad está correcta.'}</p>`, [['Aceptar', '', true]]);
  go('#/inicio', true); route();
}

/* ───────────── enrutador ───────────── */
const RUTAS = [
  [/^\/inicio$/, vInicio], [/^\/bienes$/, vBienes], [/^\/bien\/nuevo$/, () => vBienForm('nuevo')], [/^\/bien\/([^/]+)\/editar$/, vBienForm], [/^\/bien\/([^/]+)$/, vBien],
  [/^\/registrar$/, vRegistrar], [/^\/mov\/nuevo$/, vMovForm], [/^\/movimiento\/([^/]+)$/, vMov], [/^\/movimientos$/, vMovs], [/^\/recorrido$/, vRecorrido],
  [/^\/mas$/, vMas], [/^\/reportes$/, vReportes], [/^\/personas$/, vPersonas], [/^\/persona\/([^/]+)$/, vPersona], [/^\/catalogos$/, vCatalogos], [/^\/respaldo$/, vRespaldo], [/^\/ajustes$/, vAjustes]
];
async function route() {
  if (MODAL) MODAL();
  const nm = main.cloneNode(false); main.replaceWith(nm); main = nm; // contenedor limpio: sin oyentes de la pantalla anterior
  if (!CFG.setupHecho) return vSetup();
  const path = (location.hash.slice(1) || '/inicio').split('?')[0];
  for (const [re, fn] of RUTAS) { const m = path.match(re); if (m) { const t = ++RT; try { await fn(...m.slice(1)); } catch (e) { console.error(e); if (t === RT) main.innerHTML = `<div class="alert bad">Error: ${esc(e.message)}</div>`; } return; } }
  go('#/inicio', true);
}
window.addEventListener('hashchange', route);
/* botón atrás de Android: devuelve true si la app lo manejó */
window.__back = () => {
  if (MODAL) { MODAL(); return true; }
  const path = (location.hash.slice(1) || '/inicio').split('?')[0];
  if (path === '/inicio' || !CFG.setupHecho) return false;
  if (history.length > 1) history.back(); else go('#/inicio', true);
  return true;
};

(async function init() {
  try {
    await DB.open(); await loadCfg(); await loadPersonas();
    if (navigator.storage?.persist) navigator.storage.persist().catch(() => {});
    if (CFG.pinHash) bloquear();
    route();
  } catch (e) { main.innerHTML = `<div class="alert bad">No se pudo abrir la base de datos: ${esc(e.message)}</div>`; }
})();
